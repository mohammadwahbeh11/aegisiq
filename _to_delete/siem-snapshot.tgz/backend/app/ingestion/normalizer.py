"""
app/ingestion/normalizer.py

Converts a validated log-ingestion payload into the canonical
NormalizedEvent used across the SIEM (project section 7 / build-spec
Phase A.3).

Deliberately takes a plain dict, not the Pydantic LogIngestRequest --
zero dependency on FastAPI/Pydantic/SQLAlchemy, only the standard
library. This is what lets the logic in this file be executed and
verified directly (see tests/test_ingestion_normalizer.py), independent
of whether the web framework is even installed. app/ingestion/service.py
is the only caller, and it's responsible for turning a validated
LogIngestRequest into the dict shape this module expects.

Precedence rule (Phase A.6 -- "if an event is already normalized, do
not unnecessarily transform it"):
  1. Any field the client explicitly supplied is trusted as-is.
  2. A Windows Event ID fills event_type/severity ONLY if the client
     didn't already supply an explicit event_type.
  3. If event_type is still missing and raw_log is present, the line is
     parsed as a Linux auth/system log to fill remaining gaps.
  4. Anything still missing gets a safe, honestly-labeled default
     (severity="low", event_type="unparsed") -- never invented.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

AUTH_FAILURE = "authentication_failure"
AUTH_SUCCESS = "authentication_success"
PRIVILEGE_RELATED = "privilege_related"
FILE_INTEGRITY_CHANGE = "file_integrity_change"
PORT_ACCESS = "port_access"
UNPARSED = "unparsed"

# 4672 maps to "privilege_related", not "privilege_escalation": deciding
# something IS an escalation is a detection-engine judgment (Phase B),
# not something the normalization layer should assert on ingestion.
_WINDOWS_EVENT_MAP: dict[int, tuple[str, str]] = {
    4625: (AUTH_FAILURE, "medium"),
    4624: (AUTH_SUCCESS, "low"),
    4672: (PRIVILEGE_RELATED, "medium"),
}


@dataclass
class NormalizedEvent:
    timestamp: datetime
    event_type: str
    severity: str  # "low" | "medium" | "high" | "critical"
    source: str | None
    operating_system: str | None
    hostname: str | None = None
    source_ip: str | None = None
    destination_ip: str | None = None
    source_port: int | None = None
    destination_port: int | None = None
    username: str | None = None
    event_id: int | None = None
    raw_log: str | None = None
    normalized_data: dict[str, Any] = field(default_factory=dict)


def normalize(fields: dict[str, Any]) -> NormalizedEvent:
    """
    `fields` is expected to contain (all optional except at least one of
    raw_log/event_type/event_id, enforced by the schema layer):
    timestamp, hostname, source_ip, destination_ip, source_port,
    destination_port, username, event_type, severity, source,
    operating_system, event_id, raw_log, metadata.
    """
    extra: dict[str, Any] = dict(fields.get("metadata") or {})

    event_type = fields.get("event_type")
    severity = fields.get("severity")
    username = fields.get("username")
    source_ip = fields.get("source_ip")
    destination_port = fields.get("destination_port")

    event_id = fields.get("event_id")
    if event_type is None and event_id is not None and event_id in _WINDOWS_EVENT_MAP:
        mapped_type, mapped_severity = _WINDOWS_EVENT_MAP[event_id]
        event_type = mapped_type
        severity = severity or mapped_severity

    raw_log = fields.get("raw_log")
    if event_type is None and raw_log:
        parsed = _parse_linux_line(raw_log)
        if parsed is not None:
            p_event_type, p_severity, p_username, p_source_ip, p_extra = parsed
            event_type = p_event_type
            severity = severity or p_severity
            username = username or p_username
            source_ip = source_ip or p_source_ip
            if destination_port is None and "destination_port" in p_extra:
                destination_port = p_extra.pop("destination_port")
            # Client-supplied metadata wins over parser-derived extras.
            extra = {**p_extra, **extra}

    if event_type is None:
        event_type = UNPARSED
    if severity is None:
        severity = "low"

    if not raw_log:
        # No literal raw log was submitted (e.g. a fully pre-normalized
        # JSON event). Rather than store an empty string and lose the
        # submission entirely, the whole payload is preserved as JSON --
        # forensic investigation should never come up empty-handed
        # (Phase A.8 / Task 8).
        raw_log = json.dumps({k: v for k, v in fields.items() if v is not None}, default=str)

    return NormalizedEvent(
        timestamp=fields.get("timestamp") or datetime.now(timezone.utc),
        event_type=event_type,
        severity=severity,
        source=fields.get("source"),
        operating_system=fields.get("operating_system"),
        hostname=fields.get("hostname"),
        source_ip=source_ip,
        destination_ip=fields.get("destination_ip"),
        source_port=fields.get("source_port"),
        destination_port=destination_port,
        username=username,
        event_id=event_id,
        raw_log=raw_log,
        normalized_data=extra,
    )


def _parse_linux_line(
    raw_log: str,
) -> tuple[str, str, str | None, str | None, dict[str, Any]] | None:
    """Returns (event_type, severity, username, source_ip, extra), or
    None if raw_log doesn't match any recognized Linux pattern. The port
    in the "from <ip> port <n>" suffix is optional -- the project's own
    example ("Failed password for admin from 192.168.1.50") omits it."""

    m = re.search(
        r"Failed password for (?:invalid user )?(?P<username>\S+) "
        r"from (?P<source_ip>[\d.]+)(?: port (?P<port>\d+))?",
        raw_log,
    )
    if m:
        extra = {"destination_port": int(m.group("port"))} if m.group("port") else {}
        return AUTH_FAILURE, "medium", m.group("username"), m.group("source_ip"), extra

    m = re.search(
        r"Accepted password for (?P<username>\S+) from (?P<source_ip>[\d.]+)(?: port (?P<port>\d+))?",
        raw_log,
    )
    if m:
        extra = {"destination_port": int(m.group("port"))} if m.group("port") else {}
        return AUTH_SUCCESS, "low", m.group("username"), m.group("source_ip"), extra

    m = re.search(
        r"authentication failure;.*user=(?P<username>\S+).*rhost=(?P<source_ip>[\d.]+)",
        raw_log,
    )
    if m:
        return AUTH_FAILURE, "medium", m.group("username"), m.group("source_ip"), {}

    # PAM logs don't guarantee field order (rhost= often precedes user=),
    # so this is matched with two independent lookups rather than one
    # ordered regex.
    if "authentication failure" in raw_log:
        user_match = re.search(r"\buser=(?P<username>\S+)", raw_log)
        host_match = re.search(r"\brhost=(?P<source_ip>[\d.]+)", raw_log)
        if user_match or host_match:
            return (
                AUTH_FAILURE,
                "medium",
                user_match.group("username") if user_match else None,
                host_match.group("source_ip") if host_match else None,
                {},
            )

    m = re.search(r"sudo:\s*(?P<username>\S+)\s*:.*COMMAND=(?P<command>.+)", raw_log)
    if m:
        return PRIVILEGE_RELATED, "medium", m.group("username"), None, {"command": m.group("command").strip()}

    m = re.search(
        r"File integrity violation:\s*(?P<path>\S+)\s+modified by\s+(?P<username>\S+)",
        raw_log,
    )
    if m:
        return FILE_INTEGRITY_CHANGE, "high", m.group("username"), None, {"path": m.group("path")}

    m = re.search(r"Connection attempt from (?P<source_ip>[\d.]+) to port (?P<port>\d+)", raw_log)
    if m:
        return PORT_ACCESS, "low", None, m.group("source_ip"), {"destination_port": int(m.group("port"))}

    return None
