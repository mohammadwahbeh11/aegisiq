"""
Alert querying and triage (project section 11 -- the investigation page).

Reading is open to both roles; changing an alert's status is the
analyst's core action and is therefore also open to both -- triage is
literally the Security Analyst's job in the project's use-case diagram,
so restricting it to administrators would be backwards.
"""
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session, joinedload

from app.api.deps import get_db
from app.auth.dependencies import get_current_user
from app.models.alert import Alert, AlertStatus, AlertStatusHistory
from app.models.log import Log, Severity
from app.models.rule import DetectionRule
from app.models.user import User
from app.realtime.events import serialize_alert
from app.realtime.hub import EVENT_ALERT, hub
from app.schemas.alert import (
    AlertDetail,
    AlertListResponse,
    AlertLogContext,
    AlertOut,
    AlertStatusChange,
    AlertStatusUpdate,
)

router = APIRouter(prefix="/api/alerts", tags=["alerts"])

# How much surrounding evidence the investigation view pulls in. Capped
# because an alert on a busy source IP could otherwise match thousands of
# log rows and turn one page load into a table scan.
RELATED_LOG_LIMIT = 25


def _to_out(alert: Alert) -> AlertOut:
    payload = AlertOut.model_validate(alert)
    if alert.rule is not None:
        payload.rule_name = alert.rule.name
        payload.rule_type = alert.rule.rule_type
    return payload


@router.get("", response_model=AlertListResponse)
def list_alerts(
    db: Session = Depends(get_db),
    _user: User = Depends(get_current_user),
    severity: Severity | None = None,
    alert_status: AlertStatus | None = Query(default=None, alias="status"),
    source_ip: str | None = None,
    rule_id: int | None = None,
    since_hours: int | None = Query(default=None, ge=1, le=8760),
    limit: int = Query(default=100, ge=1, le=1000),
    offset: int = Query(default=0, ge=0),
):
    """Newest first. `total` is the count BEFORE limit/offset so the UI
    can show "showing 100 of 1,432" rather than implying it has
    everything."""
    query = db.query(Alert).options(joinedload(Alert.rule))

    if severity is not None:
        query = query.filter(Alert.severity == severity)
    if alert_status is not None:
        query = query.filter(Alert.status == alert_status)
    if source_ip:
        query = query.filter(Alert.source_ip == source_ip)
    if rule_id is not None:
        query = query.filter(Alert.rule_id == rule_id)
    if since_hours is not None:
        query = query.filter(
            Alert.timestamp >= datetime.now(timezone.utc) - timedelta(hours=since_hours)
        )

    total = query.count()
    alerts = query.order_by(Alert.timestamp.desc(), Alert.id.desc()).offset(offset).limit(limit).all()
    return AlertListResponse(total=total, items=[_to_out(a) for a in alerts])


@router.get("/{alert_id}", response_model=AlertDetail)
def get_alert(
    alert_id: int,
    db: Session = Depends(get_db),
    _user: User = Depends(get_current_user),
):
    alert = (
        db.query(Alert)
        .options(joinedload(Alert.rule), joinedload(Alert.log))
        .filter(Alert.id == alert_id)
        .first()
    )
    if alert is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Alert not found")

    detail = AlertDetail(**_to_out(alert).model_dump())

    rule: DetectionRule | None = alert.rule
    if rule is not None:
        detail.rule_description = rule.description
        detail.rule_threshold = rule.threshold
        detail.rule_time_window_seconds = rule.time_window_seconds

    if alert.log is not None:
        detail.triggering_log = AlertLogContext.model_validate(alert.log)

        # The evidence behind the verdict: the other events from the same
        # source, of the same type, inside the rule's own detection
        # window. This is what lets an analyst confirm or dismiss the
        # alert without writing a database query by hand.
        if rule is not None and alert.log.source_ip:
            window_start = alert.log.timestamp - timedelta(seconds=rule.time_window_seconds)
            related = (
                db.query(Log)
                .filter(
                    Log.source_ip == alert.log.source_ip,
                    Log.event_type == alert.log.event_type,
                    Log.timestamp >= window_start,
                    Log.timestamp <= alert.log.timestamp,
                )
                .order_by(Log.timestamp.desc())
                .limit(RELATED_LOG_LIMIT)
                .all()
            )
            detail.related_logs = [AlertLogContext.model_validate(row) for row in related]

    history = (
        db.query(AlertStatusHistory)
        .filter(AlertStatusHistory.alert_id == alert.id)
        .order_by(AlertStatusHistory.changed_at.asc())
        .all()
    )
    detail.status_history = [
        AlertStatusChange(
            previous_status=entry.previous_status,
            new_status=entry.new_status,
            changed_by=entry.changed_by_user.username if entry.changed_by_user else None,
            changed_at=entry.changed_at,
        )
        for entry in history
    ]
    return detail


@router.patch("/{alert_id}/status", response_model=AlertOut)
def update_alert_status(
    alert_id: int,
    payload: AlertStatusUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Triage. The change is recorded in alert_status_history (who, when,
    from what, to what) rather than only overwriting the column, so a
    "false positive" verdict can be traced back to the analyst who made
    it -- see app/models/alert.py."""
    alert = db.query(Alert).options(joinedload(Alert.rule)).filter(Alert.id == alert_id).first()
    if alert is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Alert not found")

    previous = alert.status
    if previous == payload.status:
        # Not an error, but not an audit-trail entry either -- recording
        # "changed from resolved to resolved" would be noise.
        return _to_out(alert)

    alert.status = payload.status
    db.add(
        AlertStatusHistory(
            alert_id=alert.id,
            previous_status=previous,
            new_status=payload.status,
            changed_by=user.id,
        )
    )
    db.commit()
    db.refresh(alert)

    # Other analysts' open consoles see the triage immediately, which is
    # what stops two people working the same alert.
    hub.publish(EVENT_ALERT, serialize_alert(alert))
    return _to_out(alert)
