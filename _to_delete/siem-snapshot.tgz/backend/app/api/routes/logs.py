from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.auth.dependencies import get_current_user
from app.ingestion.schemas import LogIngestRequest, LogIngestResponse
from app.ingestion.service import ingest_log
from app.models.log import Log, Severity
from app.schemas.log import LogListResponse, LogOut

router = APIRouter(prefix="/api/logs", tags=["logs"])


@router.post("", response_model=LogIngestResponse, status_code=201)
def create_log(
    payload: LogIngestRequest,
    db: Session = Depends(get_db),
    _user=Depends(get_current_user),
):
    """
    Authenticate (existing get_current_user dependency, reused as-is) ->
    validate (LogIngestRequest) -> ingest_log() does normalize -> store
    -> broadcast -> detection -> SOAR (see app/ingestion/service.py).
    """
    return ingest_log(payload, db)


@router.get("", response_model=LogListResponse)
def list_logs(
    db: Session = Depends(get_db),
    _user=Depends(get_current_user),
    severity: Severity | None = None,
    event_type: str | None = None,
    source_ip: str | None = None,
    hostname: str | None = None,
    username: str | None = None,
    search: str | None = Query(default=None, max_length=200),
    since_hours: int | None = Query(default=None, ge=1, le=8760),
    limit: int = Query(default=100, ge=1, le=1000),
    offset: int = Query(default=0, ge=0),
):
    """
    Log search, newest first. `total` is the match count BEFORE
    limit/offset, so the UI can honestly say "showing 100 of 12,904"
    instead of implying the page is everything.

    `search` is a substring match over the raw log line and the parsed
    username/hostname. It is deliberately a LIKE, not a full-text index:
    at this project's scale a LIKE over an indexed-by-time working set is
    fast enough, and adding FTS5 tables would cost storage and a schema
    migration for a feature no requirement asks for.
    """
    query = db.query(Log)

    if severity is not None:
        query = query.filter(Log.severity == severity)
    if event_type:
        query = query.filter(Log.event_type == event_type)
    if source_ip:
        query = query.filter(Log.source_ip == source_ip)
    if hostname:
        query = query.filter(Log.hostname == hostname)
    if username:
        query = query.filter(Log.username == username)
    if since_hours is not None:
        query = query.filter(Log.timestamp >= datetime.now(timezone.utc) - timedelta(hours=since_hours))
    if search:
        pattern = f"%{search}%"
        query = query.filter(
            or_(
                Log.raw_log.ilike(pattern),
                Log.username.ilike(pattern),
                Log.hostname.ilike(pattern),
                Log.event_type.ilike(pattern),
            )
        )

    total = query.count()
    rows = query.order_by(Log.timestamp.desc(), Log.id.desc()).offset(offset).limit(limit).all()
    return LogListResponse(total=total, items=[LogOut.model_validate(row) for row in rows])


@router.get("/event-types", response_model=list[str])
def list_event_types(db: Session = Depends(get_db), _user=Depends(get_current_user)):
    """The event types actually present in this database, for populating
    the search filter. Derived from the data rather than a hardcoded list
    because event_type is intentionally an open string -- new log sources
    introduce new types without a schema change (see app/models/log.py)."""
    rows = db.query(Log.event_type).distinct().order_by(Log.event_type).all()
    return [row[0] for row in rows]


@router.get("/{log_id}", response_model=LogOut)
def get_log(log_id: int, db: Session = Depends(get_db), _user=Depends(get_current_user)):
    log = db.query(Log).filter(Log.id == log_id).first()
    if log is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Log not found")
    return LogOut.model_validate(log)
