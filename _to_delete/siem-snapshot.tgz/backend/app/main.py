import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import (
    agents,
    alerts,
    auth,
    dashboard,
    health,
    integrations,
    logs,
    rules,
    simulation,
    soar,
    stream,
)
from app.config import get_settings
from app.core.init_db import init_db
from app.realtime.hub import hub

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    # Hand the running event loop to the realtime hub. The ingestion path
    # is synchronous and therefore runs on FastAPI's worker threads, which
    # cannot touch a WebSocket directly -- they schedule the broadcast
    # onto this loop instead. See app/realtime/hub.py.
    hub.bind_loop(asyncio.get_running_loop())
    try:
        yield
    finally:
        hub.unbind_loop()


app = FastAPI(
    title=settings.PROJECT_NAME,
    description=(
        "Lightweight SIEM & SOAR for resource-constrained environments. "
        "Native FastAPI/SQLite implementation of the graduation project's "
        "architecture (see docs/architecture.md for why this replaces the "
        "Wazuh + Elasticsearch + Kibana stack described in the original "
        "document, and how a real Wazuh Manager can still be plugged in "
        "as an optional upstream)."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router)
app.include_router(auth.router)
app.include_router(agents.router)
app.include_router(dashboard.router)
app.include_router(logs.router)
app.include_router(alerts.router)
app.include_router(rules.router)
app.include_router(soar.router)
app.include_router(integrations.router)
app.include_router(simulation.router)
app.include_router(stream.router)
