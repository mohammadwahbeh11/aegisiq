"""
Central configuration for the Lightweight SIEM backend.

All values are overridable via environment variables (see .env.example).
No secrets are hardcoded here -- defaults exist only so the app can boot
in a fresh dev environment, and DEFAULT_ADMIN_PASSWORD must be changed
after first login (see README "Default administrator account").
"""
from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

# Repository root (backend/app/config.py -> backend/app -> backend -> root).
# Used to anchor the default SQLite path and the .env location so the app
# behaves identically no matter which directory uvicorn is launched from,
# and no matter which machine the project was copied onto.
REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_SQLITE_PATH = REPO_ROOT / "data" / "siem.db"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=str(REPO_ROOT / ".env"), extra="ignore")

    # General
    PROJECT_NAME: str = "Lightweight SIEM"
    ENV: str = "development"

    # Database. Absolute by default (see REPO_ROOT above) rather than the
    # old relative "sqlite:///./data/siem.db", which silently created a
    # second, empty database whenever the server was started from a
    # different working directory.
    DATABASE_URL: str = f"sqlite:///{DEFAULT_SQLITE_PATH.as_posix()}"

    # Auth / JWT
    SECRET_KEY: str = "dev-secret-key-change-me"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

    # Default administrator account (created on first startup if no users exist)
    DEFAULT_ADMIN_USERNAME: str = "admin"
    DEFAULT_ADMIN_PASSWORD: str = "ChangeMe123!"

    # CORS - comma separated list of allowed origins. A single "*" allows
    # any origin, which is convenient on a lab network where the analyst
    # browses the console from a Kali VM whose IP changes between runs.
    CORS_ORIGINS: str = "http://localhost:5173,http://127.0.0.1:5173"

    # Resource / retention settings (used by later phases; declared now so
    # they are configurable from day one instead of hardcoded later)
    LOG_RETENTION_DAYS: int = 30
    ALERT_RETENTION_DAYS: int = 90
    MAX_DB_SIZE_MB: int = 500

    # --- SOAR (automated response) ---
    # When enabled, high/critical alerts record a containment action.
    # SOAR_EXECUTE=false means actions are RECORDED but never actually
    # executed against a host -- see app/soar/engine.py. There is no code
    # path in this project that runs a real firewall command; setting
    # SOAR_EXECUTE=true only marks actions as intended-for-execution so a
    # real executor can be plugged in later without changing the schema.
    SOAR_ENABLED: bool = True
    SOAR_EXECUTE: bool = False

    # --- Optional Wazuh integration ---
    # Left blank => the integration reports "not_configured" instead of
    # pretending a manager is connected (app/integrations/wazuh.py).
    WAZUH_URL: str = ""
    WAZUH_USERNAME: str = ""
    WAZUH_PASSWORD: str = ""
    WAZUH_VERIFY_SSL: bool = False
    WAZUH_TIMEOUT_SECONDS: float = 5.0

    @property
    def cors_origins_list(self) -> list[str]:
        return [origin.strip() for origin in self.CORS_ORIGINS.split(",") if origin.strip()]

    @property
    def wazuh_configured(self) -> bool:
        return bool(self.WAZUH_URL.strip())


@lru_cache
def get_settings() -> Settings:
    return Settings()
