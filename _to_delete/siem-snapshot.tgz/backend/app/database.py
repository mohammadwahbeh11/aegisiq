"""
SQLAlchemy setup.

Lightweight version uses SQLite (see .env DATABASE_URL). The engine is
built with a URL string only -- no SQLite-specific code leaks into the
models or routes -- so swapping DATABASE_URL to a PostgreSQL DSN later
(e.g. postgresql+psycopg://...) requires no code changes, only adding
the driver to requirements.txt.
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

from app.config import get_settings

settings = get_settings()

connect_args = {}
if settings.DATABASE_URL.startswith("sqlite"):
    # Required for SQLite when accessed from multiple threads (FastAPI's
    # default threaded request handling).
    connect_args = {"check_same_thread": False}

engine = create_engine(settings.DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()
