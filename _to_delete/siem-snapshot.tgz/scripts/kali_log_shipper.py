#!/usr/bin/env python3
"""
scripts/kali_log_shipper.py -- run this ON the Linux/Kali box, not on the
SIEM host.

Tails a real log file (default /var/log/auth.log) and ships each new line
to the Lightweight SIEM's ingestion API. This is what turns the project
from "a SIEM that analyses events it generated itself" into "a SIEM
watching a real machine": run this on the target, launch a real attack
against that target from Kali, and the alerts in the console come from
genuine sshd/sudo output.

It ships raw lines and lets the SIEM's normalizer parse them
(app/ingestion/normalizer.py), rather than parsing on the endpoint --
keeping the shipper trivial, and keeping one parser to reason about.

Typical lab setup
-----------------
  SIEM host (Windows, this repo)  ->  http://192.168.100.66:8000
  Target    (Ubuntu/Kali VM)      ->  runs this script against its own auth.log
  Attacker  (Kali)                ->  runs the attack at the target

On the target:
    sudo python3 kali_log_shipper.py \
        --url http://192.168.100.66:8000 \
        --file /var/log/auth.log \
        --hostname ubuntu-web-01

From the attacker box, real tra