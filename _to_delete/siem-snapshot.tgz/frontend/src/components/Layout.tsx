import { useEffect, useState } from "react";
import { NavLink, Outlet } from "react-router-dom";

import { useAuth } from "../context/AuthContext";
import { useLive } from "../context/LiveContext";
import ToastRail from "./ToastRail";

const NAV_ITEMS = [
  { to: "/dashboard", label: "Dashboard", glyph: "▤" },
  { to: "/alerts", label: "Alerts", glyph: "!" },
  { to: "/logs", label: "Log search", glyph: "≡" },
  { to: "/rules", label: "Detection rules", glyph: "◈" },
  { to: "/endpoints", label: "Endpoints", glyph: "▣" },
  { to: "/response", label: "Automated response", glyph: "⚙" },
  { to: "/simulation", label: "Simulation lab", glyph: "▶", adminOnly: true },
];

const CONNECTION_LABEL: Record<string, string> = {
  connecting: "Connecting…",
  live: "Live",
  reconnecting: "Reconnecting…",
  offline: "Offline",
};

export default function Layout() {
  const { user, logout } = useAuth();
  const { connection, eventCount, liveAlerts } = useLive();
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const isAdmin = user?.role === "administrator";
  const newAlertCount = liveAlerts.filter((alert) => alert.status === "new").length;

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand-block">
          <div className="brand">Lightweight SIEM</div>
          <div className="brand-sub">SOC &amp; automated response console</div>
        </div>

        <nav>
          {NAV_ITEMS.filter((item) => !item.adminOnly || isAdmin).map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
            >
              <span className="nav-glyph" aria-hidden="true">
                {item.glyph}
              </span>
              <span>{item.label}</span>
              {item.to === "/alerts" && newAlertCount > 0 && (
                <span className="nav-count">{newAlertCount}</span>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="user-footer">
          <div className="user-name">{user?.username}</div>
          <div className="role">{user?.role?.replace("_", " ")}</div>
          <button className="logout-btn" onClick={logout}>
            Sign out
          </button>
        </div>
      </aside>

      <div className="main-column">
        <header className="top-status-bar">
          <div className={`connection-pill ${connection}`}>
            <span className="dot" aria-hidden="true" />
            {CONNECTION_LABEL[connection] ?? connection}
            {connection === "live" && (
              <span className="pill-detail">{eventCount} events this session</span>
            )}
          </div>
          <div className="clock">{now.toLocaleString()}</div>
        </header>

        <main className="main-content">
          <Outlet />
        </main>
      </div>

      <ToastRail />
    </div>
  );
}
