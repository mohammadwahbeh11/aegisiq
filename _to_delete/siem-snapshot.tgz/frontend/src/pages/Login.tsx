import { FormEvent, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import { fetchHealth } from "../api/client";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [backend, setBackend] = useState<"checking" | "up" | "down">("checking");

  // Check the backend before anyone types a password. Without this, an
  // unreachable API is indistinguishable from a wrong password, and the
  // first thing people do is retype credentials that were never wrong --
  // especially likely here, where the console and the API can sit on
  // different machines on a lab network.
  useEffect(() => {
    fetchHealth()
      .then(() => setBackend("up"))
      .catch(() => setBackend("down"));
  }, []);

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setError(null);
    setIsSubmitting(true);
    try {
      await login(username, password);
      navigate("/dashboard");
    } catch (err: unknown) {
      const status = (err as { response?: { status?: number } })?.response?.status;
      if (status === 401) {
        setError("Incorrect username or password.");
      } else if (status === undefined) {
        setError(
          "Could not reach the backend. Check that the API is running and that VITE_API_URL points at it."
        );
      } else {
        setError(`The backend rejected the request (HTTP ${status}).`);
      }
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="centered-screen">
      <div className="login-card">
        <h1>Lightweight SIEM</h1>
        <p className="subtitle">Sign in to the security operations console</p>

        <div className={`backend-check ${backend}`}>
          <span className="dot" aria-hidden="true" />
          {backend === "checking" && "Checking backend…"}
          {backend === "up" && "Backend reachable"}
          {backend === "down" && "Backend unreachable"}
        </div>

        {error && <div className="error-banner">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="username">Username</label>
            <input
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="username"
              autoFocus
              required
            />
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              required
            />
          </div>
          <button className="btn-primary" type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Signing in…" : "Sign in"}
          </button>
        </form>
      </div>
    </div>
  );
}
