import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";

import {
  Alert,
  DashboardStats,
  MitreCoverageRow,
  Severity,
  TimelineBucket,
  fetchDashboardStats,
  fetchMitreCoverage,
  fetchSeverityDistribution,
  fetchTimeline,
  fetchTopSources,
} from "../api/client";
import { ActivityTimeline, SeverityDonut } from "../components/charts";
import {
  EmptyState,
  ErrorBanner,
  Loading,
  MitreBadge,
  Panel,
  SeverityBadge,
  StatusBadge,
  formatRelative,
  formatTime,
} from "../components/ui";
import { useLive } from "../context/LiveContext";

const EMPTY_COUNTS: Record<Severity, number> = { critical: 0, high: 0, medium: 0, low: 0 };

export default function Dashboard() {
  const { liveLogs, liveAlerts, onAlert, connection } = useLive();

  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [severityCounts, setSeverityCounts] = useState<Record<Severity, number>>(EMPTY_COUNTS);
  const [timeline, setTimeline] = useState<TimelineBucket[]>([]);
  const [topSources, setTopSources] = useState<{ source_ip: string; alerts: number }[]>([]);
  const [coverage, setCoverage] = useState<MitreCoverageRow[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const [statsData, severityData, timelineData, sourcesData, coverageData] = await Promise.all([
        fetchDashboardStats(),
        fetchSeverityDistribution(),
        fetchTimeline(24),
        fetchTopSources(5),
        fetchMitreCoverage(),
      ]);
      setStats(statsData);
      setSeverityCounts({ ...EMPTY_COUNTS, ...severityData.counts });
      setTimeline(timelineData);
      setTopSources(sourcesData);
      setCoverage(coverageData);
      setError(null);
    } catch {
      setError("Could not load dashboard data from the backend.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  // The aggregates are recomputed when an alert actually arrives rather
  // than on a timer: nothing has changed between alerts, so polling would
  // be five queries a second producing identical numbers.
  useEffect(() => onAlert(() => void load()), [onAlert, load]);

  if (isLoading) return <Loading label="Loading dashboard…" />;

  const recentAlerts: Alert[] = liveAlerts.slice(0, 8);

  return (
    <>
      <div className="page-head">
        <div>
          <h2>Security operations dashboard</h2>
          <p className="page-sub">
            Every figure below is computed from stored events — there are no placeholder numbers.
          </p>
        </div>
      </div>

      {error && <ErrorBanner>{error}</ErrorBanner>}

      {stats && (
        <div className="kpi-grid">
          <KpiCard label="Total events" value={stats.total_events.toLocaleString()} hint={`${stats.events_today.toLocaleString()} today`} />
          <KpiCard label="Active alerts" value={stats.active_alerts} hint="new + investigating" tone={stats.active_alerts > 0 ? "warn" : undefined} />
          <KpiCard label="Critical alerts" value={stats.critical_alerts} tone={stats.critical_alerts > 0 ? "critical" : undefined} />
          <KpiCard label="High alerts" value={stats.high_alerts} tone={stats.high_alerts > 0 ? "high" : undefined} />
          <KpiCard label="Endpoints online" value={`${stats.online_endpoints} / ${stats.monitored_endpoints}`} />
          <KpiCard
            label="Containment actions"
            value={stats.soar_actions}
            hint="recorded, not executed"
          />
          <KpiCard
            label="Detection rate"
            value={stats.detection_rate === null ? "n/a" : `${stats.detection_rate}%`}
            hint={stats.detection_rate === null ? "no alerts raised yet" : "alerts not dismissed as false positives"}
          />
          <KpiCard
            label="Mean detection time"
            value={
              stats.avg_detection_time_seconds === null
                ? "n/a"
                : `${stats.avg_detection_time_seconds}s`
            }
            hint="event timestamp → alert raised"
          />
        </div>
      )}

      <div className="grid-2">
        <Panel title="Active alerts by severity">
          <SeverityDonut counts={severityCounts} />
        </Panel>

        <Panel title="Activity — last 24 hours">
          <ActivityTimeline buckets={timeline} />
        </Panel>
      </div>

      <div className="grid-2">
        <Panel
          title="Live alert feed"
          actions={<Link className="link-btn" to="/alerts">Open alert queue →</Link>}
        >
          {recentAlerts.length === 0 ? (
            <EmptyState>
              {connection === "live"
                ? "Connected and listening. Alerts appear here the moment a rule fires — run a scenario from the Simulation lab to see it happen."
                : "The live connection is not established, so no streaming alerts can be shown."}
            </EmptyState>
          ) : (
            <ul className="feed">
              {recentAlerts.map((alert) => (
                <li key={alert.id}>
                  <Link to={`/alerts/${alert.id}`} className="feed-row">
                    <SeverityBadge severity={alert.severity} />
                    <div className="feed-body">
                      <div className="feed-title">{alert.rule_name ?? "Detection rule"}</div>
                      <div className="feed-desc">{alert.description}</div>
                    </div>
                    <div className="feed-meta">
                      <StatusBadge status={alert.status} />
                      <span className="muted">{formatRelative(alert.timestamp)}</span>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel
          title="Live event stream"
          actions={<Link className="link-btn" to="/logs">Search all logs →</Link>}
        >
          {liveLogs.length === 0 ? (
            <EmptyState>
              No events received on this connection yet. Ingested logs appear here in real time.
            </EmptyState>
          ) : (
            <div className="table-scroll compact">
              <table>
                <thead>
                  <tr>
                    <th>Time</th>
                    <th>Event</th>
                    <th>Source</th>
                    <th>Severity</th>
                  </tr>
                </thead>
                <tbody>
                  {liveLogs.slice(0, 12).map((log) => (
                    <tr key={log.id}>
                      <td className="muted">{formatTime(log.timestamp)}</td>
                      <td>{log.event_type}</td>
                      <td className="mono">{log.source_ip ?? log.hostname ?? "—"}</td>
                      <td>
                        <SeverityBadge severity={log.severity} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Panel>
      </div>

      <div className="grid-2">
        <Panel title="Top alerting sources">
          {topSources.length === 0 ? (
            <EmptyState>No alerts with a source address have been raised yet.</EmptyState>
          ) : (
            <ul className="ranked-list">
              {topSources.map((row) => (
                <li key={row.source_ip}>
                  <Link to={`/alerts?source_ip=${encodeURIComponent(row.source_ip)}`} className="mono">
                    {row.source_ip}
                  </Link>
                  <span className="count">{row.alerts}</span>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel title="MITRE ATT&CK / Cyber Kill Chain coverage">
          <div className="table-scroll compact">
            <table>
              <thead>
                <tr>
                  <th>Rule</th>
                  <th>Technique</th>
                  <th>Kill chain phase</th>
                  <th>Alerts</th>
                </tr>
              </thead>
              <tbody>
                {coverage.map((row) => (
                  <tr key={row.rule_id} className={row.enabled ? "" : "row-disabled"}>
                    <td>
                      {row.rule_name}
                      {!row.enabled && <span className="tag">disabled</span>}
                    </td>
                    <td>
                      <MitreBadge id={row.mitre_id} />
                    </td>
                    <td className="muted">{row.kill_chain_phase ?? "—"}</td>
                    <td>{row.alerts}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      </div>
    </>
  );
}

function KpiCard({
  label,
  value,
  hint,
  tone,
}: {
  label: string;
  value: string | number;
  hint?: string;
  tone?: "critical" | "high" | "warn";
}) {
  return (
    <div className={`kpi-card ${tone ?? ""}`}>
      <div className="label">{label}</div>
      <div className="value">{value}</div>
      {hint && <div className="hint">{hint}</div>}
    </div>
  );
}
