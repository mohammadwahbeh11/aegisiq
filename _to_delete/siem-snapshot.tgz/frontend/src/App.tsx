import { Navigate, Route, Routes } from "react-router-dom";

import Layout from "./components/Layout";
import { useAuth } from "./context/AuthContext";
import { LiveProvider } from "./context/LiveContext";
import AlertDetail from "./pages/AlertDetail";
import Alerts from "./pages/Alerts";
import Dashboard from "./pages/Dashboard";
import Endpoints from "./pages/Endpoints";
import Login from "./pages/Login";
import Logs from "./pages/Logs";
import Response from "./pages/Response";
import Rules from "./pages/Rules";
import Simulation from "./pages/Simulation";

/**
 * The LiveProvider wraps the whole authenticated area rather than any
 * single page, so the WebSocket survives navigation: moving from the
 * dashboard to the alert queue must not drop and re-open the stream, and
 * the alert toast has to appear no matter which page is open.
 */
function ProtectedArea() {
  const { isAuthenticated } = useAuth();
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  return (
    <LiveProvider>
      <Layout />
    </LiveProvider>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route element={<ProtectedArea />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/alerts" element={<Alerts />} />
        <Route path="/alerts/:alertId" element={<AlertDetail />} />
        <Route path="/logs" element={<Logs />} />
        <Route path="/rules" element={<Rules />} />
        <Route path="/endpoints" element={<Endpoints />} />
        <Route path="/response" element={<Response />} />
        <Route path="/simulation" element={<Simulation />} />
      </Route>
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}
