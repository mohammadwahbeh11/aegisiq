import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:8000";

export const apiClient = axios.create({ baseURL: API_URL });

// Token is kept in localStorage for simplicity in this foundation phase.
// Known trade-off: localStorage is readable by any JS on the page, so it
// is more XSS-exposed than an httpOnly cookie. Acceptable for a local
// graduation-project demo; documented here rather than silently assumed.
const TOKEN_KEY = "siem_access_token";

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken(): void {
  localStorage.removeItem(TOKEN_KEY);
}

apiClient.interceptors.request.use((config) => {
  const token = getToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

/**
 * The WebSocket URL for the live stream, derived from the same base URL
 * as the REST calls so a deployment only has to configure VITE_API_URL
 * once (http -> ws, https -> wss). A relative VITE_API_URL falls back to
 * the page's own origin.
 */
export function streamUrl(token: string): string {
  const base = new URL(API_URL, window.location.origin);
  base.protocol = base.protocol === "https:" ? "wss:" : "ws:";
  base.pathname = "/ws/stream";
  base.search = `?token=${encodeURIComponent(token)}`;
  return base.toString();
}

// ---------------------------------------------------------------------------
// Shared types
// ---------------------------------------------------------------------------

export type Severity = "low" | "medium" | "high" | "critical";
export type AlertStatus = "new" | "investigating" | "resolved" | "false_positive";
export type UserRole = "administrator" | "security_analyst";

export interface LoginResponse {
  access_token: string;
  token_type: string;
  username: string;
  role: UserRole;
}

export interface DashboardStats {
  total_events: number;
  events_today: number;
  active_alerts: number;
  critical_alerts: number;
  high_alerts: number;
  monitored_endpoints: number;
  online_endpoints: number;
  detection_rate: number | null;
  avg_detection_time_seconds: number | null;
  soar_actions: number;
  soar_actions_today: number;
}

export interface Alert {
  id: number;
  timestamp: string;
  severity: Severity;
  status: AlertStatus;
  source_ip: string | null;
  destination_ip: string | null;
  rule_id: number;
  rule_name: string | null;
  rule_type: string | null;
  mitre_id: string | null;
  kill_chain_phase: string | null;
  description: string;
  log_id: number | null;
  incident_id: number | null;
  created_at: string | null;
}

export interface LogEvent {
  id: number;
  timestamp: string;
  hostname: string | null;
  source_ip: string | null;
  destination_ip: string | null;
  source_port: number | null;
  destination_port: number | null;
  username: string | null;
  event_type: string;
  event_id: number | null;
  severity: Severity;
  source: string;
  operating_system: string | null;
  raw_log: string;
  normalized_data: Record<string, unknown> | null;
  agent_id: number | null;
}

export interface AlertStatusChange {
  previous_status: AlertStatus | null;
  new_status: AlertStatus;
  changed_by: string | null;
  changed_at: string | null;
}

export interface AlertDetail extends Alert {
  rule_description: string | null;
  rule_threshold: number | null;
  rule_time_window_seconds: number | null;
  triggering_log: LogEvent | null;
  related_logs: LogEvent[];
  status_history: AlertStatusChange[];
}

export interface DetectionRule {
  id: number;
  name: string;
  description: string;
  rule_type: string;
  threshold: number;
  time_window_seconds: number;
  severity: Severity;
  mitre_id: string | null;
  kill_chain_phase: string | null;
  parameters: Record<string, unknown> | null;
  enabled: boolean;
  implemented: boolean;
}

export interface SoarAction {
  id: number;
  timestamp: string | null;
  action_type: string;
  target: string;
  alert_id: number | null;
  rule_name: string | null;
  status: "simulated" | "pending" | "executed" | "failed";
  detail: string | null;
  execution_requested: boolean;
}

export interface SoarActionsResponse {
  total: number;
  enabled: boolean;
  execution_mode: "record_only" | "execute_requested";
  items: SoarAction[];
}

export interface EndpointRow {
  source: "local" | "wazuh";
  agent_id: string | null;
  hostname: string | null;
  ip_address: string | null;
  operating_system: string | null;
  status: string | null;
  last_seen: string | null;
  version: string | null;
}

export interface WazuhStatus {
  status: "not_configured" | "connected" | "unreachable" | "unauthorized" | "error";
  url: string | null;
  detail: string;
  agent_count: number | null;
}

export interface EndpointsOverview {
  total: number;
  sources: { local: number; wazuh: number };
  wazuh_integration: WazuhStatus;
  items: EndpointRow[];
}

export interface Scenario {
  key: string;
  name: string;
  description: string;
  expected_rules: string[];
  event_count: number;
  estimated_seconds: number;
}

export interface HealthReport {
  api: string;
  database: string;
  detection_engine: string;
  detection_rules_implemented: string[];
  detection_rules_enabled_without_handler: string[];
  collector: string;
  websocket: string;
  websocket_subscribers: number;
  soar: string;
  wazuh: string;
}

export interface MitreCoverageRow {
  rule_id: number;
  rule_name: string;
  rule_type: string;
  mitre_id: string | null;
  kill_chain_phase: string | null;
  severity: Severity;
  enabled: boolean;
  alerts: number;
}

export interface TimelineBucket {
  hour: string;
  events: number;
  alerts: number;
}

// ---------------------------------------------------------------------------
// Calls
// ---------------------------------------------------------------------------

export async function login(username: string, password: string): Promise<LoginResponse> {
  const response = await apiClient.post<LoginResponse>("/api/auth/login", { username, password });
  return response.data;
}

export async function fetchHealth(): Promise<HealthReport> {
  // The only unauthenticated endpoint -- used by the login screen to say
  // whether the backend is even reachable before blaming the password.
  const response = await apiClient.get<HealthReport>("/health");
  return response.data;
}

export async function fetchDashboardStats(): Promise<DashboardStats> {
  const response = await apiClient.get<DashboardStats>("/api/dashboard/stats");
  return response.data;
}

export async function fetchSeverityDistribution(): Promise<{
  counts: Record<Severity, number>;
  total: number;
}> {
  const response = await apiClient.get("/api/dashboard/severity-distribution");
  return response.data;
}

export async function fetchTimeline(hours = 24): Promise<TimelineBucket[]> {
  const response = await apiClient.get("/api/dashboard/timeline", { params: { hours } });
  return response.data.buckets;
}

export async function fetchTopSources(limit = 5): Promise<{ source_ip: string; alerts: number }[]> {
  const response = await apiClient.get("/api/dashboard/top-sources", { params: { limit } });
  return response.data;
}

export async function fetchMitreCoverage(): Promise<MitreCoverageRow[]> {
  const response = await apiClient.get<MitreCoverageRow[]>("/api/dashboard/mitre-coverage");
  return response.data;
}

export interface AlertQuery {
  severity?: Severity;
  status?: AlertStatus;
  source_ip?: string;
  rule_id?: number;
  since_hours?: number;
  limit?: number;
  offset?: number;
}

export async function fetchAlerts(query: AlertQuery = {}): Promise<{ total: number; items: Alert[] }> {
  const response = await apiClient.get("/api/alerts", { params: query });
  return response.data;
}

export async function fetchAlert(id: number): Promise<AlertDetail> {
  const response = await apiClient.get<AlertDetail>(`/api/alerts/${id}`);
  return response.data;
}

export async function updateAlertStatus(id: number, status: AlertStatus): Promise<Alert> {
  const response = await apiClient.patch<Alert>(`/api/alerts/${id}/status`, { status });
  return response.data;
}

export interface LogQuery {
  severity?: Severity;
  event_type?: string;
  source_ip?: string;
  hostname?: string;
  username?: string;
  search?: string;
  since_hours?: number;
  limit?: number;
  offset?: number;
}

export async function fetchLogs(query: LogQuery = {}): Promise<{ total: number; items: LogEvent[] }> {
  const response = await apiClient.get("/api/logs", { params: query });
  return response.data;
}

export async function fetchEventTypes(): Promise<string[]> {
  const response = await apiClient.get<string[]>("/api/logs/event-types");
  return response.data;
}

export async function fetchRules(): Promise<DetectionRule[]> {
  const response = await apiClient.get<DetectionRule[]>("/api/rules");
  return response.data;
}

export async function updateRule(
  id: number,
  changes: Partial<Pick<DetectionRule, "threshold" | "time_window_seconds" | "severity" | "enabled">>
): Promise<DetectionRule> {
  const response = await apiClient.patch<DetectionRule>(`/api/rules/${id}`, changes);
  return response.data;
}

export async function fetchSoarActions(limit = 100): Promise<SoarActionsResponse> {
  const response = await apiClient.get<SoarActionsResponse>("/api/soar/actions", {
    params: { limit },
  });
  return response.data;
}

export async function fetchEndpoints(): Promise<EndpointsOverview> {
  const response = await apiClient.get<EndpointsOverview>("/api/agents/overview");
  return response.data;
}

export async function fetchWazuhStatus(): Promise<WazuhStatus> {
  const response = await apiClient.get<WazuhStatus>("/api/integrations/wazuh/status");
  return response.data;
}

export async function fetchScenarios(): Promise<Scenario[]> {
  const response = await apiClient.get<Scenario[]>("/api/simulation/scenarios");
  return response.data;
}

export interface ScenarioRunResponse {
  status: string;
  scenario: string;
  name: string;
  event_count: number;
  estimated_seconds: number;
  expected_rules: string[];
  detail: string;
}

export async function runScenario(key: string): Promise<ScenarioRunResponse> {
  const response = await apiClient.post<ScenarioRunResponse>(`/api/simulation/run/${key}`);
  return response.data;
}
