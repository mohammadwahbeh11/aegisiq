# AegisIQ + Groq — free Llama 3.3 70B setup (v2.5.1)

## Why Groq

For an AegisIQ deployment that wants real AI Copilot output **without paying anyone**:

| Requirement                       | Groq              | OpenAI            | Gemini Free        |
|-----------------------------------|-------------------|-------------------|--------------------|
| Credit card at signup             | ❌ Not required   | ✅ Required       | ❌ Not required    |
| Free requests per day             | 14,400            | 0 (paid)          | 1,500              |
| Model quality (MMLU %)            | Llama 3.3 70B: 87 | gpt-4o-mini: 82   | Gemini 2.5 Flash: 79 |
| Trains on your data?              | ❌ No             | ❌ No (default)   | ⚠️ Yes on free tier |
| Latency                           | ~0.5 s            | ~1.5 s            | ~1.0 s             |
| Arabic support                    | Yes (Llama)       | Yes               | Yes                |

For a **security product**, Groq is the only free option — Gemini's data-training clause makes it unsuitable to send customer alert bodies through.

## 60-second signup

1. Open https://console.groq.com — sign in with Google or GitHub (no card).
2. Click **API Keys** → **Create API Key** → name it `aegisiq-prod` → copy the `gsk_...` value.
3. That's it. No billing, no quota approval, no email verification wait.

## Install the provider

From the repo root on your Windows machine:

```powershell
# Copy the drop files into Downloads first, then:
powershell -ExecutionPolicy Bypass -File "C:\Users\ONE BY ONE\Downloads\scripts\apply_groq_provider.ps1"
cd frontend; npm run build; cd ..
git add backend/app/ai/groq_provider.py backend/app/ai/providers.py backend/app/config.py
git commit -m "feat(ai): add Groq provider (free Llama 3.3 70B)"
git push
```

## Configure on Render

Dashboard → `aegisiq-backend` → **Environment** → add these three:

| Key             | Value                                       |
|-----------------|---------------------------------------------|
| `AI_PROVIDER`   | `groq`                                      |
| `GROQ_API_KEY`  | `gsk_XXXXXXXXXXXXXXXXXXXX` (from console)   |
| `AI_MODEL`      | `llama-3.3-70b-versatile`                   |

**Save Changes** → Render redeploys automatically (~90 seconds).

## Verify

1. Open https://aegisiq-frontend.onrender.com/intelligence
2. Header should now read: **Provider: groq • Model: llama-3.3-70b-versatile**
3. Enter Alert ID `1`, choose **العربية**, click **Explain with AI**
4. Response arrives in ~1 second — full Arabic explanation with recommended actions.

## Rate-limit safety

Groq free tier: 30 requests/min, 14,400 requests/day, ~12k tokens/min. For any SMB running AegisIQ this is generous — a single analyst working full-time triggers maybe 200 explanations/day. If you need more, `AI_PROVIDER=openai` (paid) is a one-env-var swap.

## What runs where

- **Alert body** (the raw log line and normalized fields) → sent to Groq's LPU endpoint over HTTPS.
- **Groq's stated policy** (as of 2026-09): "We do not train models on user data." Verify the current policy at https://groq.com/privacy-policy before enterprise deployment.
- **PII in logs**: if your logs contain PII you're uncomfortable sharing with any third-party inference provider, run Ollama locally instead (`AI_PROVIDER=ollama`, `OLLAMA_URL=http://your-host:11434`).
