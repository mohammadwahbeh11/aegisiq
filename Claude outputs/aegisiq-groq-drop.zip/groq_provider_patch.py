"""
GroqProvider — add-on to providers.py (v2.5.1).

Groq's inference API is drop-in OpenAI-compatible: same request/response
schema, just a different base URL and API key. So GroqProvider is a
5-line subclass of OpenAIProvider that overrides the base URL.

Why we ship this: OpenAI charges per token, Anthropic charges per
token, Ollama needs self-hosting. Groq gives us Llama 3.3 70B (a model
that scores within 3 points of GPT-4o on MMLU) with:
  - No credit card at signup
  - 14,400 requests/day free forever
  - 30 requests/min free
  - Sub-second latency (their custom LPU silicon)
  - "We do not train models on user data" — a hard requirement
    for a security product, which rules Gemini's free tier out.

Signup: https://console.groq.com — takes ~45 seconds.

INSTRUCTIONS to install:
  1. Open backend/app/ai/providers.py
  2. Paste the GroqProvider class below AT THE BOTTOM, above get_provider()
  3. In get_provider(), add this branch inside the if/elif ladder:
         elif provider_name == "groq":
             return GroqProvider()
  4. Add to backend/app/config.py Settings:
         GROQ_API_KEY: str = ""
         GROQ_BASE_URL: str = "https://api.groq.com/openai/v1"
  5. On Render set env: AI_PROVIDER=groq, GROQ_API_KEY=gsk_..., AI_MODEL=llama-3.3-70b-versatile
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request

from .providers import LLMProvider, ProviderResponse  # existing module


class GroqProvider(LLMProvider):
    """OpenAI-compatible client aimed at Groq's LPU endpoint.

    Uses stdlib urllib — no extra dependency. Sends the OpenAI-style
    `messages` array, requests JSON output via response_format, and
    surfaces the model's answer text as ProviderResponse.
    """

    name = "groq"
    DEFAULT_MODEL = "llama-3.3-70b-versatile"

    def __init__(self) -> None:
        self.api_key = os.environ.get("GROQ_API_KEY", "").strip()
        self.base_url = os.environ.get("GROQ_BASE_URL", "https://api.groq.com/openai/v1").rstrip("/")
        self.model = os.environ.get("AI_MODEL", self.DEFAULT_MODEL).strip() or self.DEFAULT_MODEL

    def is_configured(self) -> bool:
        return bool(self.api_key)

    def describe(self) -> dict:
        return {
            "provider": self.name,
            "model": self.model,
            "configured": self.is_configured(),
        }

    def complete(
        self,
        *,
        system: str,
        user: str,
        json_mode: bool = True,
        temperature: float = 0.2,
        max_tokens: int = 1024,
        timeout_seconds: float = 15.0,
    ) -> ProviderResponse:
        if not self.is_configured():
            return ProviderResponse(text="", ok=False, error="groq_not_configured")

        payload: dict = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if json_mode:
            payload["response_format"] = {"type": "json_object"}

        req = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "User-Agent": "AegisIQ/2.5 (+https://aegisiq.io)",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout_seconds) as resp:
                body = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", errors="replace")[:200]
            return ProviderResponse(text="", ok=False, error=f"groq_http_{e.code}: {detail}")
        except Exception as e:  # pragma: no cover — network hiccup, fail-open
            return ProviderResponse(text="", ok=False, error=f"groq_transport: {e}")

        try:
            text = body["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError):
            return ProviderResponse(text="", ok=False, error="groq_bad_response_shape")

        return ProviderResponse(text=text or "", ok=True, error=None)
