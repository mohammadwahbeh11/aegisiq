# apply_groq_provider.ps1 -- add Groq (free Llama 3.3 70B) as the 4th AI provider.
# Fully automatic: patches providers.py, config.py, copies the class file.

$ErrorActionPreference = 'Stop'
$repo = "C:\Users\ONE BY ONE\Downloads\lightweight-siem"
$src  = "C:\Users\ONE BY ONE\Downloads"

Write-Host "Installing Groq provider into: $repo"

# 1) Copy the GroqProvider source file into ai/
$aiDir = Join-Path $repo 'backend\app\ai'
if (-not (Test-Path $aiDir)) { throw "backend\app\ai does not exist. Is the repo checked out?" }
Copy-Item -Force "$src\groq_provider_patch.py" "$aiDir\groq_provider.py"
Write-Host "  OK backend\app\ai\groq_provider.py"

# 2) Patch providers.py — register the branch inside get_provider()
$provPath = Join-Path $aiDir 'providers.py'
if (-not (Test-Path $provPath)) { throw "providers.py missing — check the v2.5 push landed." }
$prov = Get-Content $provPath -Raw
if ($prov -notmatch 'from \.groq_provider') {
    $prov = "from .groq_provider import GroqProvider  # v2.5.1 free Groq (Llama 3.3 70B)`r`n" + $prov
}
if ($prov -notmatch 'GroqProvider\(\)') {
    # Insert an elif before the final "raise" or "return" fallback in get_provider()
    $prov = $prov -replace '(\bdef get_provider[^\n]*\n(?:[^\n]*\n)*?)(\s+)(raise|return\s+[A-Za-z]*Provider\(\)|return\s+None)',
        "`$1`$2if (provider_name or '').lower() == 'groq':`$2    return GroqProvider()`$2`$3"
}
Set-Content -Path $provPath -Value $prov -NoNewline
Write-Host "  OK providers.py patched"

# 3) Patch config.py — add GROQ_API_KEY / GROQ_BASE_URL settings
$cfgPath = Join-Path $repo 'backend\app\config.py'
$cfg = Get-Content $cfgPath -Raw
if ($cfg -notmatch 'GROQ_API_KEY') {
    $cfg = $cfg -replace '(class Settings\(BaseSettings\):[^\n]*\n(?:[^\n]*\n)*?)(\s+@property)',
        "`$1    # --- v2.5.1 Groq (free Llama 3.3 70B, no credit card) ---`r`n    GROQ_API_KEY: str = `"`"`r`n    GROQ_BASE_URL: str = `"https://api.groq.com/openai/v1`"`r`n`$2"
    Set-Content -Path $cfgPath -Value $cfg -NoNewline
    Write-Host "  OK config.py patched"
} else {
    Write-Host "  SKIP config.py already has GROQ_API_KEY"
}

Write-Host ""
Write-Host "Groq provider installed. Next:"
Write-Host "  git add backend/app/ai/groq_provider.py backend/app/ai/providers.py backend/app/config.py"
Write-Host "  git commit -m 'feat(ai): add Groq provider (free Llama 3.3 70B, no credit card)'"
Write-Host "  git push"
Write-Host ""
Write-Host "Then on Render (Environment):"
Write-Host "  AI_PROVIDER    = groq"
Write-Host "  GROQ_API_KEY   = gsk_XXXXXXXXXX  (get from https://console.groq.com/keys)"
Write-Host "  AI_MODEL       = llama-3.3-70b-versatile"
