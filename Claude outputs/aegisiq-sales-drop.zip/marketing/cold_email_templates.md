# Cold email templates — AegisIQ

Rules for every email below:
- **Under 90 words.** A CISO will not read more.
- **One ask.** Never two.
- **No attachment on cold email.** Link to the deck.
- **From a personal domain** (mohammad@aegisiq.io), never a mass-send tool.
- **Never "just checking in."** If they didn't reply, send new value.

---

## Template 1 — CISO / IT Manager at a MENA SMB (50-500 employees)

**Subject:** `[FIRSTNAME], Splunk pricing question`

```
Hi [FIRSTNAME],

I'm building AegisIQ — an Arabic-native SIEM designed for firms your size in the Gulf who can't justify a Splunk contract. It's live in production, open-core, with an AI Copilot that triages alerts in Arabic.

We're taking three design partners this quarter: 6 months of Pro tier free, in exchange for one 30-minute call per month.

Would a 15-minute demo next week interest you? I can show it on a real alert stream, in Arabic.

Live demo: aegisiq-frontend.onrender.com

Mohammad Wahbeh
Founder, AegisIQ
```

**When to send:** Tuesday or Wednesday, 9:30 AM in their timezone.
**Follow-up:** ONE follow-up 5 business days later — different subject, different value.

---

## Template 2 — MSSP / Managed SOC provider

**Subject:** `Reselling an Arabic SIEM for your GCC book`

```
Hi [FIRSTNAME],

I run AegisIQ — a bilingual open-core SIEM. Two of the tools we compete with (Splunk, Sentinel) have no Arabic UI, and Wazuh has no built-in AI triage or compliance reports.

If you serve MENA SMBs, we're launching a reseller tier: 40% margin on Pro seats, white-label option on Enterprise. First 5 partners get co-marketing.

Would a 20-minute chat next week make sense? I'll walk through the multi-tenant roadmap and the current commission structure.

Deck: aegisiq.io/deck

Mohammad Wahbeh
```

**When to send:** Wednesday or Thursday, 10 AM local.

---

## Template 3 — Angel investor / MENA VC

**Subject:** `Arabic-native SIEM, $49/analyst, hitting revenue`

```
Hi [FIRSTNAME],

I'm raising a $100k pre-seed for AegisIQ — an open-core SIEM built for the Arabic-speaking SMB security market Splunk and Sentinel abandoned.

Live product, first paying pilot underway, targeting $10k MRR in 12 months. Solo founder, MENA-based, computer engineering background.

12-slide deck (5 min read): aegisiq.io/deck
Live product: aegisiq-frontend.onrender.com

Would a 20-minute call next week fit your calendar? Happy to send financials.

Mohammad Wahbeh
```

**When to send:** Monday morning. Investors triage inboxes Monday.

---

## Template 4 — Existing Wazuh user (found via GitHub issues, r/wazuh, or LinkedIn)

**Subject:** `The triage layer I wish Wazuh shipped with`

```
Hi [FIRSTNAME],

Saw your comment on [WAZUH_ISSUE_URL / SUBREDDIT] — the frustration with [SPECIFIC PAIN THEY MENTIONED] is exactly what pushed me to build AegisIQ.

It's an open-core layer that sits on top of Wazuh: takes the alert stream, runs it through an AI Copilot (free Llama 3.3 70B tier, no card), auto-generates SOC 2 evidence, and triggers HMAC-signed containment orders back to the endpoint.

MIT-adjacent license, live demo up, no signup: aegisiq-frontend.onrender.com

Would love your honest feedback — you clearly know the space.

Mohammad
```

**When to send:** Within 48 hours of their public comment. Speed matters.

---

## Template 5 — Compliance officer / auditor (SOC 2 / ISO 27001 / GDPR shop)

**Subject:** `Live compliance evidence from a SIEM, not a spreadsheet`

```
Hi [FIRSTNAME],

I built AegisIQ partly to solve the "SOC 2 evidence is a manual month every quarter" problem. It generates SOC 2, ISO 27001 Annex A, and GDPR Article 30 evidence live from the audit log — timestamped, defensible, auditor-friendly.

If you help clients through audits, I'd love your critique of the report format. Would 20 minutes next week work?

Sample report (SOC 2 CC6-CC7): [LINK]

Mohammad Wahbeh
Founder, AegisIQ
```

**Why this works:** compliance people love saying "no, that wouldn't fly with an auditor." Give them permission to critique — you'll get 3× the response rate.

---

## Reply handling — the three inbound patterns

### Pattern A: "Sounds interesting, send more info"
→ Do NOT send more info. Reply: *"Happy to — a 15-min call gets you a demo tailored to your stack. Grab any slot: [CALENDLY_LINK]"*

### Pattern B: "We already use X"
→ Do NOT try to displace them. Reply: *"That's a solid choice. AegisIQ often runs alongside [X] as the Arabic-triage layer — not a replacement. If that's ever useful, here's the demo: [LINK]. Otherwise good luck with the current stack."*

### Pattern C: "How much does it cost?"
→ Reply with the exact pricing, not a "let's chat about pricing" dodge: *"Community is free forever. Pro is $49/analyst/month, month-to-month via Stripe. Enterprise starts at $12k/year for multi-tenant + SSO. Full breakdown: aegisiq.io/pricing"*

## What to track per template

| Template | Sent | Opens | Replies | Meetings | Conversions |
|---|---|---|---|---|---|
| CISO/SMB | | | | | |
| MSSP | | | | | |
| Investor | | | | | |
| Wazuh user | | | | | |
| Compliance | | | | | |

Aim for: 30% open rate, 5% reply rate, 2% meeting rate. If any row is 3x below these, rewrite the subject line first, then the opener.
