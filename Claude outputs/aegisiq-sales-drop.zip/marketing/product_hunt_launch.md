# Product Hunt launch — AegisIQ

## Tagline (60 characters max)

```
Arabic-native SIEM with free AI Copilot for MENA SMBs
```

## Description (260 characters — Product Hunt hard limit)

```
Splunk starts at $1,800/GB. AegisIQ starts at $0. Open-core SIEM/SOAR with bilingual AI Copilot (free Llama 3.3 70B), live SOC 2/ISO 27001/GDPR evidence, and a Kill-Switch agent. Built for the Arabic-speaking SMBs enterprise security leaves behind.
```

## Topics to tag

- Developer Tools
- Security
- Open Source
- Artificial Intelligence
- SaaS

## Gallery (5 images — order matters)

1. **Dashboard hero shot** — full-width dashboard with populated demo data (12+ events, colored severity KPIs, alerts sidebar showing badge count).
2. **AI Copilot in action** — Intelligence page with an Arabic response filling the panel. Zoom to make the Arabic legible.
3. **Compliance report** — SOC 2 evidence page rendered to HTML, showing control-by-control coverage.
4. **Kill-Switch flow** — architecture diagram showing alert → SOAR engine → HMAC-signed order → endpoint agent → containment.
5. **Comparison table** — the Splunk/Wazuh/Sentinel/AegisIQ grid from the pitch deck.

Each image labeled with a one-line caption for context.

## First comment (post this yourself immediately after launch — pinned)

```
Hey Product Hunters!

I'm Mohammad, the maker of AegisIQ. Two things pushed me to build this:

1. My family in Amman runs a 40-person logistics business and got quoted $58,000/year for Splunk. That's more than their entire IT budget.

2. Every "affordable" SIEM tutorial I found assumed English-only operators. Try running a SOC when half your team switches languages mid-alert.

So I built an open-core SIEM where:
- Community edition is free forever (self-host on a $7 VPS)
- Pro is $49/analyst/month for AI Copilot + threat intel + compliance reports
- The AI Copilot uses Groq's free Llama 3.3 70B tier — no credit card needed to try

Would especially love feedback from:
- MSSPs serving MENA/GCC markets
- Anyone who's had to run a SOC on a shoestring
- Security engineers who think my fail-open architecture is a bad idea

Live demo: https://aegisiq-frontend.onrender.com (login: admin / ChangeMe123!)
Code: https://github.com/mohammadwahbeh11/aegisiq

Ask me anything — technical, business, threat model, "why not X."
```

## Hunter outreach — do this a week before launch

Message 3-5 established security-space hunters and ask if they'd like to hunt AegisIQ. Best candidates:
- Someone who has previously hunted a security tool that hit top 5
- A MENA-based hunter (regional angle)
- A developer-tools hunter with a security bent

Sample DM:

```
Hey [name],

Big fan of your hunt of [X] — the way you framed [Y] was spot-on.

I'm launching AegisIQ next week — it's an open-core Arabic-native SIEM with a free AI Copilot tier (using Groq's Llama 3.3 70B). Live demo up already: aegisiq-frontend.onrender.com

If it looks interesting, would you consider hunting it on Wednesday, [DATE]? Happy to walk you through it first.

No worries either way — thanks for the great launches you've put out.

Mohammad
```

## Launch-day timing (all times Pacific)

- **00:01 PT** — post goes live automatically
- **00:05 PT** — post your pinned first comment
- **07:00 PT** — send a single email to your list ("we're live on PH today")
- **09:00 PT** — post one LinkedIn post (English) and one X post
- **12:00 PT** — post the same content in Arabic
- **15:00 PT** — reply to every top-level comment
- **21:00 PT** — post a thank-you comment recapping the top questions of the day

## Rules of the road

- ❌ NEVER ask for votes explicitly ("please upvote me!"). PH detects it and demotes.
- ❌ NEVER buy votes. Every provider is a scam and PH bans instantly.
- ❌ NEVER create sockpuppet accounts.
- ✅ DO reply to every comment within 30 min for the first 6 hours.
- ✅ DO share the direct URL, not the shortened one — PH's algorithm weights direct link traffic.
- ✅ DO thank the hunter publicly at the end of the day.
