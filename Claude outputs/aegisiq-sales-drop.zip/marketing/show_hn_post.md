# Show HN launch — AegisIQ

## Title (copy this exact line)

```
Show HN: AegisIQ – Arabic-native SIEM with AI Copilot on free Llama 3.3 70B
```

**Why this title works:** the "Arabic-native" hook signals the moat in 2 words; "AI Copilot" tells the audience what they get; "free Llama 3.3 70B" is the tangible proof that beats every "we use AI" post from last week. All under 80 chars, no emoji, no all-caps, no marketing verbs.

## Post body

```
Hey HN,

I built AegisIQ because Splunk quotes to Arabic-speaking SMBs in the Gulf come back at $60k/year before a single analyst is hired, and every "affordable" alternative assumes English-only operators. It's a full open-core SIEM/SOAR with the pieces that usually get bolted on later:

- 8 built-in detection rules (SSH brute-force, port scan, priv-esc, malware, exfil, lateral movement, etc.) mapped to MITRE ATT&CK
- AI Copilot that explains any alert in Arabic or English — pluggable across OpenAI, Anthropic, Ollama, and (new this week) Groq's free Llama 3.3 70B tier so you get a real 87-MMLU model without a credit card
- Live SOC 2 / ISO 27001 / GDPR evidence reports generated from the audit log (no manual spreadsheets)
- Composite IP reputation (70% AbuseIPDB + 30% AlienVault OTX) with a 6-hour cache
- Kill-Switch endpoint agent — HMAC-SHA256 signed containment orders, ~3s from alert to firewall rule
- MFA (TOTP RFC 6238), AES-256-GCM secret encryption, 8-layer defense-in-depth doc
- Pluggable event store (SQLite / OpenSearch / ClickHouse) so it scales from a $20 VPS to a real cluster
- WebSocket dashboard, Sigma rule import, audit log, retention policy

Stack: FastAPI + React/TypeScript + SQLite/PostgreSQL. Runs in under 500 MB RAM. Elastic License 2.0.

Live demo (login: admin / ChangeMe123!):
https://aegisiq-frontend.onrender.com

Code:
https://github.com/mohammadwahbeh11/aegisiq

Some design choices I'd love feedback on:
1. Fail-open architecture — every external dependency (LLM, threat intel, webhook) can be absent and the core still ships alerts. Wrong call for a security product?
2. HMAC-signed Kill-Switch orders instead of mutual TLS. Cheaper to deploy on the edge, but I'm second-guessing the trade-off.
3. Compliance evidence generated on demand rather than continuously exported. Auditor-friendly, but expensive at scale.

Roadmap: multi-tenant workspaces, SSO/SAML, native Wazuh agent adapter, Arabic-first playbook library. Happy to answer anything — implementation, threat model, business model, or "why not just Wazuh."
```

## Timing

- **Best day:** Tuesday or Wednesday. Never Monday (traffic hangover), never Friday (weekend fade).
- **Best hour:** 8:00-8:30 AM Pacific Time. This is when the largest wave of US developers checks HN before standup.
- **What NOT to do:** ask friends to upvote in the first hour (HN detects vote rings and shadow-suppresses the post).

## Comment-management playbook

Have these three drafts ready **before** you post — copy-paste when the questions land, which they will within 30 minutes:

### If someone asks "why not just use Wazuh?"

```
Fair question — Wazuh is what I actually use as an ingest agent on the endpoints. AegisIQ is the correlation/triage/response layer on top. Wazuh gives you EDR events, AegisIQ gives you Arabic-language triage + built-in compliance reports + a working SOAR loop. The two compose; they don't compete.
```

### If someone asks about hosting cost / TCO

```
The reference deployment on Render costs $7/month for the backend + $0 for the frontend (static). SQLite works up to ~5M events; past that you swap in the OpenSearch or ClickHouse backend via a single env var. Groq's free Llama 3.3 70B tier covers the Copilot at zero, up to 14,400 explanations per day. Real total for a 50-person org: under $10/month.
```

### If someone challenges the "$60k Splunk" number

```
Fair pushback — Splunk pricing varies enormously by contract. The $60k number is what a 50-employee firm in Riyadh paid last year for 20 GB/day ingest with a 90-day retention SKU. Splunk's ELA program can drop that significantly for enterprise, but SMBs almost never qualify.
```

## Metrics to track

- Front page hits (~30 upvotes gets you there in the first hour if the title lands)
- Time on demo site (Plausible or Umami tells you)
- GitHub star velocity (aim for 100+ stars in the first 24 hours)
- Sales inbox: expect 3-8 real inquiries out of every 1,000 HN visitors

## Follow-up posts (2-week cadence)

- Week +2: Show HN — AegisIQ multi-tenant is here (when you ship it)
- Week +4: Blog post cross-linked from HN: "What running a free-tier SIEM in production for a month taught me"
- Week +6: Show HN — SOC 2 Type I audit results for a real customer (if you land one)

Never post to the same subreddit twice in the same week.
