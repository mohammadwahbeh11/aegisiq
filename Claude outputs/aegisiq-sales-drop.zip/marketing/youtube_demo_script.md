# YouTube demo script — AegisIQ (5 minutes, bilingual)

## Video metadata

**Title (English):**
`I built the SIEM Splunk pretends doesn't exist — for $7/month`

**Title (Arabic):**
`بنيت SIEM كامل بـ7 دولار شهرياً — بديل عربي احترافي لـSplunk`

**Description (paste both languages):**
```
AegisIQ is an open-core SIEM/SOAR platform with bilingual AI triage, live compliance evidence, and a $7/month deployment cost. Live demo, code, and pitch deck below.

🔗 Live demo: https://aegisiq-frontend.onrender.com  (login: admin / ChangeMe123!)
🔗 Code: https://github.com/mohammadwahbeh11/aegisiq
🔗 Pitch deck: https://aegisiq.io/deck

Timestamps:
00:00 What is AegisIQ
00:30 Live dashboard walkthrough
01:15 An alert appears — triage in Arabic
02:30 Kill-Switch containment demo
03:15 SOC 2 evidence in 5 seconds
04:00 The $7/month deployment recipe
04:45 What's next & how to help

مشروع AegisIQ منصة SIEM/SOAR مفتوحة المصدر بواجهة عربية وذكاء اصطناعي مجاني للفرز.

#Cybersecurity #SIEM #OpenSource #MENA
```

## Thumbnail

- Left half: AegisIQ dashboard with clearly-visible Arabic Copilot response
- Right half: Big text "$7/mo" with strikethrough "$58k/yr"
- Font: bold sans-serif, high contrast (light background, dark text — reads on mobile)

## Script

### Scene 1 — Hook (0:00-0:30) — camera on presenter

> **[EN]** "In 2025, a friend's 50-person company in the Gulf got quoted fifty-eight thousand dollars a year for Splunk. So I spent six months building this."
>
> **[AR overlay caption]** "كوّت شركة صديقي في السعودية 58 ألف دولار سنوياً لـSplunk. فبنيت هذا."

Cut to laptop screen showing the dashboard.

### Scene 2 — Dashboard tour (0:30-1:15) — screen recording

Walk through:
- The live indicator ("Live • X events this session")
- Severity KPI cards
- Detection rules panel (show all 8 rules with MITRE ATT&CK tags)
- Endpoints view

> "This is running on a seven-dollar-a-month Render container. It's ingesting live events, running eight detection rules mapped to MITRE ATT&CK, and pushing everything through a WebSocket to this dashboard in real time."

### Scene 3 — Alert triage in Arabic (1:15-2:30) — screen recording

- Click into an SSH brute-force alert
- Navigate to Intelligence page
- Enter alert ID, select العربية
- Click "Explain with AI"
- Wait ~1s for Groq response
- Highlight the Arabic explanation with cursor

> "This is running on Groq's free Llama 3.3 70B tier — no credit card, no API cost, and the response is in Arabic. This is the moment the product becomes different from anything else in the market."

### Scene 4 — Kill-Switch (2:30-3:15) — screen recording + terminal

- Show the SOAR Response page with the containment action
- Cut to a terminal window showing the endpoint agent receiving the HMAC-signed order
- Show iptables/nftables rule being added

> "The containment order is HMAC-SHA256 signed. The endpoint agent verifies the signature before it does anything. Three seconds from alert to blocked IP."

### Scene 5 — Compliance in 5 seconds (3:15-4:00) — screen recording

- Navigate to Intelligence → Compliance Evidence
- Click "Report" on SOC 2
- New tab opens with the rendered HTML report
- Scroll through the CC6.1-CC7.4 controls with real evidence timestamps

> "This report used to take my compliance friends fifteen days to compile per audit. Now it's five seconds and every control has a timestamped audit-log event backing it."

### Scene 6 — Deployment recipe (4:00-4:45) — screen recording + code

Show:
- Render deployment YAML
- Environment variables list (with values masked)
- Cost breakdown: Backend $7, Frontend $0, DB $0 (SQLite), AI $0 (Groq free), Threat intel $0 (AbuseIPDB free), Total = $7

> "The stack: FastAPI plus React plus SQLite plus Groq's free tier plus AbuseIPDB's free tier plus Render's cheapest paid plan. Seven dollars a month for a fifty-person organization."

### Scene 7 — Call to action (4:45-5:00) — camera on presenter

> **[EN]** "The community edition is free forever. Pro is forty-nine dollars per analyst per month, and it's how I keep the lights on. Link to the live demo and the code in the description. If you're building anything similar, or if you're an Arabic-speaking security team who felt priced out — DM me. Thanks for watching."
>
> **[AR overlay]** "النسخة المجتمعية مجانية للأبد. النسخة المدفوعة 49 دولار للمحلل شهرياً. الرابط في الوصف."

## Production notes

- **Length**: aim for 4:50 to 5:20 — YouTube algorithm favors 5-8 minute videos for tech content.
- **Camera segments**: shoot at 4K, upload at 1440p (better compression at same visual quality).
- **Screen recording**: 60fps, 1920×1080, use OBS with browser source for zero-lag capture.
- **Audio**: USB condenser mic ($60 range). Poor audio kills a good demo faster than poor video.
- **Music**: none. Silence between segments reads as "professional, not staged." Music in tech demos signals "influencer, don't trust."
- **Captions**: burn in both English and Arabic captions. Half your audience watches on mute during work.

## After publishing

1. Cross-post to LinkedIn (native video, don't just link YouTube — algorithm penalizes external links).
2. Post to r/cybersecurity, r/sysadmin, r/opensource — one subreddit per day, not all at once.
3. Tweet the video with a 60-second clip attached as native video.
4. Email your beta list with "quick 5-min tour of what shipped this week."
5. Reply to every YouTube comment in the first 48 hours — retention is the algorithm's #1 signal.
