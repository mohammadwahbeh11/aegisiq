# LinkedIn launch posts — AegisIQ

Post ONE per week. Alternate Arabic and English. Never re-post the same content in both languages back-to-back — reads as spam.

## Post 1 — English — The "why I built this" story

```
Splunk quoted a friend's 50-person logistics firm in Amman $58,000/year.

That's more than their entire IT budget.

I spent the last six months building AegisIQ — an open-core SIEM with bilingual AI triage — because that quote is not unusual, and every alternative I evaluated assumed English-only operators.

What it does:
• Detects the attacks Splunk detects, but on a $7 VPS
• Explains every alert in Arabic or English (free Llama 3.3 70B tier)
• Generates SOC 2 / ISO 27001 / GDPR evidence live from the audit log
• Ships HMAC-signed containment orders to endpoints in under 3 seconds

v2.6 is live. Community edition is free forever. Live demo (no signup):
aegisiq-frontend.onrender.com

Feedback welcome from anyone who has ever tried to run a SOC on a shoestring, or from Arabic-speaking security teams who've felt priced out.

#Cybersecurity #SIEM #OpenSource #MENA #Startups
```

Post Tuesday 9:00 AM local.

---

## Post 2 — Arabic — Community-focused

```
سؤال صريح لكل مسؤول أمن معلومات في السعودية والإمارات والأردن ومصر:

كم دفعتم آخر مرة على Splunk أو مثيلاتها؟

بنيت AegisIQ لأن السوق يفرض على شركة صغيرة أن تدفع 60,000$ سنوياً على SIEM قبل أن توظف محللاً واحداً. وكل حل "اقتصادي" وجدته يفترض أن فريقك يتحدث الإنجليزية فقط.

ما يقدمه المشروع:
• كشف نفس الهجمات التي يكشفها Splunk، على خادم بـ7 دولار شهرياً
• شرح كل تنبيه بالعربية بواسطة Llama 3.3 70B مجاناً
• توليد تقارير SOC 2 و ISO 27001 و GDPR تلقائياً من سجل التدقيق
• إرسال أوامر احتواء موقّعة بـHMAC للـEndpoint خلال 3 ثوانٍ

المشروع مفتوح المصدر (ELv2)، النسخة المجتمعية مجانية للأبد.

عرض حي (بدون تسجيل):
aegisiq-frontend.onrender.com

أستقبل نقدكم بترحاب — خصوصاً من فرق SOC العربية التي شعرت بأن السوق العالمي تجاهلها.

#الأمن_السيبراني #SIEM #مفتوح_المصدر #ريادة_أعمال
```

Post Wednesday 10:00 AM Riyadh time. Include a screenshot of the Arabic Copilot response.

---

## Post 3 — English — The technical deep-dive

```
Design decision I'd love your feedback on:

AegisIQ (my open-source SIEM) is fail-open by architecture. Every external dependency — AI provider, threat intel API, webhook, external event store — can be down, misconfigured, or missing entirely. The core detection loop still ships alerts.

The trade-off:
✅ A misconfigured Groq key doesn't take down triage
✅ AbuseIPDB rate-limiting doesn't stall the SOC
✅ Customer runs the community edition without ANY external service
❌ Silent degradation risk: an ops team may not notice they've lost enrichment
❌ Every "degraded" mode is a new code path to test

I chose fail-open because the alternative — every downstream service becoming a hard dependency — is how a security tool becomes a security incident.

But I'm second-guessing whether the "silent degradation" risk deserves louder in-UI signaling. Right now degraded modes show a small banner; that may not be enough.

How do you handle this in your own security stack?

Code: github.com/mohammadwahbeh11/aegisiq

#CybersecurityEngineering #SoftwareArchitecture #OpenSource
```

Post Thursday 11:00 AM. Comment engagement post — invite debate.

---

## Post 4 — Arabic — The compliance angle

```
سؤال لكل مسؤول امتثال (Compliance Officer):

كم يوماً بالضبط تحتاجونه لتجهيز أدلة SOC 2 في كل تدقيق ربع سنوي؟

معظم من سألتهم قالوا: 15 إلى 25 يوم عمل. لجمع لقطات شاشة، وسحب سجلات، وربطها يدوياً بالضوابط.

في AegisIQ نولد هذه الأدلة تلقائياً من سجل التدقيق — كل ضابط من ضوابط SOC 2 CC6 وCC7 يظهر مع التاريخ والوقت والحدث الفعلي الذي يثبته. تقرير HTML قابل للتصدير كـPDF مباشرة.

نفس الشيء لـISO 27001 Annex A وGDPR Article 30.

النسخة المدفوعة (49$ للمحلل شهرياً) تُرسل تقريراً شهرياً تلقائياً إلى بريدكم في الأول من كل شهر. لا تدخل يدوي.

جربوا العرض الحي:
aegisiq-frontend.onrender.com → Intelligence → Compliance Evidence

سأكون ممتناً لأي تعليق من محاسبين أو مدققين على شكل التقرير — إذا فيه شيء لن يقنع مدقق حقيقي، اسمعوني قبل أن يقنع عميلاً.

#الامتثال #SOC2 #ISO27001 #GDPR
```

Post Sunday 10:00 AM Riyadh. Compliance folks read on Sundays in the Gulf work week.

---

## Post 5 — English — Traction / social proof (post AFTER first paying customer)

```
Three months ago I posted here about launching AegisIQ.

Today: [X] GitHub stars, [Y] design-partner conversations, and [Z] paying customer(s) on the Pro tier.

More importantly: the first customer runs a 42-person fintech in Riyadh. Their previous SIEM vendor's monthly bill was 34× what they pay us. Their Arabic-speaking SOC lead sent me a screenshot of the Copilot response that flagged a real incident last week — the first one caught before it hit the CFO's laptop.

That's the market that exists. Splunk and Sentinel can keep the Fortune 500. This one has been quietly waiting.

Next milestones:
• Multi-tenant workspaces (Q4)
• First MSSP reseller (Q4)
• YC / Techstars MENA application (Q1)

If you know a MENA SMB running a lean SOC, or an MSSP looking to broaden their book, DM me — I'd love an intro.

aegisiq.io · github.com/mohammadwahbeh11/aegisiq
```

Post the moment you close #1. Include a redacted screenshot from the customer (with permission).

---

## Cadence & guardrails

- One post per week, minimum. Two per week, maximum.
- Never post on Fridays — engagement drops 60%.
- Never respond to a comment more than 24 hours late.
- Never argue with a critic in comments; DM them and offer a call.
- Every 4th post should feature someone else (a customer, a contributor, a designer partner) — reciprocity beats broadcast.
- Track: impressions, comments, DMs, calls booked. Not likes.
