# AegisIQ commercial licensing notice

The AegisIQ open-source codebase is offered under the **Elastic License 2.0 (ELv2)**. In plain language:

**You CAN:**
- Use AegisIQ Community internally in your organization — commercial use included.
- Modify the source, keep those modifications private.
- Distribute AegisIQ to your customers as part of a wider service or product.
- Fork it, learn from it, teach with it.

**You CANNOT:**
- Offer AegisIQ **itself** to third parties as a hosted service (Software-as-a-Service where AegisIQ is the product being sold).
- Remove or alter the AegisIQ branding, license notices, or copyright.
- Circumvent the license-key mechanism gating premium features.

If you want to offer AegisIQ as a managed service to your customers, contact **sales@aegisiq.io** for a commercial reseller license — usually a revenue-share arrangement.

The **Pro** and **Enterprise** tiers are separately licensed and billed via Stripe subscription. Cancellation ends access to Pro-tier features but never disables the Community core you already have running.

Full ELv2 text: <https://www.elastic.co/licensing/elastic-license>
