/**
 * Pricing page (v2.6).
 *
 * The commercial conversion surface. Reads plans from /api/billing/status,
 * launches Stripe Checkout on click, and falls back to a mailto:sales
 * link when Stripe isn't configured on the deployment — so the page still
 * captures leads on day one.
 */
import { useEffect, useState } from "react";

import { apiClient } from "../api/client";
import { ErrorBanner, Loading, Panel } from "../components/ui";
import { useAuth } from "../context/AuthContext";

interface Plan {
  id: "community" | "pro" | "enterprise";
  name: string;
  price_usd: number;
  features: string[];
  contact_sales?: boolean;
}

interface BillingStatus {
  configured: boolean;
  mode: "live" | "test" | "not_configured";
  plans: Plan[];
}

// Set on Render via VITE_STRIPE_PRO_PRICE_ID — a real Stripe Price ID
// (price_XXXX). Left blank in dev; the checkout button then hits the
// mailto: fallback below.
const PRO_PRICE_ID = import.meta.env.VITE_STRIPE_PRO_PRICE_ID ?? "";

async function startCheckout(priceId: string, email?: string): Promise<{ url: string; fallback?: string }> {
  const { data } = await apiClient.post("/api/billing/checkout", {
    price_id: priceId,
    quantity: 1,
    customer_email: email,
  });
  return { url: data.checkout_url, fallback: data.fallback_mailto };
}

export default function Pricing() {
  const { user } = useAuth();
  const [status, setStatus] = useState<BillingStatus | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [starting, setStarting] = useState(false);

  useEffect(() => {
    apiClient
      .get<BillingStatus>("/api/billing/status")
      .then((r) => setStatus(r.data))
      .catch(() => setError("Could not load pricing. Please refresh."));
  }, []);

  async function handleUpgrade() {
    if (!PRO_PRICE_ID) {
      // No Stripe price wired yet — send the lead through email.
      window.location.href = "mailto:sales@aegisiq.io?subject=AegisIQ%20Pro%20upgrade";
      return;
    }
    setStarting(true);
    try {
      const { url, fallback } = await startCheckout(PRO_PRICE_ID, user?.email);
      if (url) {
        window.location.href = url;
      } else if (fallback) {
        window.location.href = fallback;
      } else {
        setError("Checkout is temporarily unavailable. Please contact sales@aegisiq.io.");
      }
    } catch {
      setError("Checkout failed. Please try again or contact sales@aegisiq.io.");
    } finally {
      setStarting(false);
    }
  }

  if (!status && !error) return <Loading label="Loading pricing…" />;

  return (
    <div className="page">
      <header className="page-header">
        <div>
          <h1>Pricing</h1>
          <p className="muted">
            Start free. Upgrade when compliance, AI triage, or threat intel become worth
            the coffee you drink each morning.
          </p>
        </div>
      </header>

      {error && <ErrorBanner>{error}</ErrorBanner>}
      {status?.mode === "test" && (
        <ErrorBanner>Stripe is in TEST mode — checkouts will not charge real cards.</ErrorBanner>
      )}
      {status?.mode === "not_configured" && (
        <ErrorBanner>
          Stripe not yet configured on this deployment — the upgrade button will open a sales email
          instead of a checkout.
        </ErrorBanner>
      )}

      <div className="pricing-grid" style={{ display: "grid", gap: "1rem", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))" }}>
        {status?.plans.map((plan) => (
          <Panel key={plan.id} title={plan.name}>
            <div style={{ fontSize: "2rem", fontWeight: 700, margin: "0.5rem 0" }}>
              {plan.contact_sales ? "Custom" : plan.price_usd === 0 ? "Free" : `$${plan.price_usd}`}
              {!plan.contact_sales && plan.price_usd > 0 && (
                <span className="muted" style={{ fontSize: "0.9rem", fontWeight: 400 }}> /analyst/month</span>
              )}
            </div>
            <ul style={{ paddingLeft: "1.2rem", margin: "0.75rem 0" }}>
              {plan.features.map((f) => (
                <li key={f} style={{ marginBottom: "0.35rem" }}>{f}</li>
              ))}
            </ul>
            {plan.id === "community" && (
              <a className="btn btn-secondary" href="https://github.com/mohammadwahbeh11/aegisiq" target="_blank" rel="noopener noreferrer">
                Get on GitHub
              </a>
            )}
            {plan.id === "pro" && (
              <button className="btn btn-primary" onClick={handleUpgrade} disabled={starting}>
                {starting ? "Redirecting…" : "Upgrade to Pro"}
              </button>
            )}
            {plan.id === "enterprise" && (
              <a className="btn btn-secondary" href="mailto:sales@aegisiq.io?subject=AegisIQ%20Enterprise">
                Contact sales
              </a>
            )}
          </Panel>
        ))}
      </div>

      <p className="muted" style={{ marginTop: "2rem", fontSize: "0.85rem" }}>
        All plans include HTTPS, MFA, audit log, data-at-rest encryption of secrets, and the same
        core detection engine. Pro/Enterprise add the paid features shown above and priority updates.
        Prices in USD, taxes calculated at checkout.
      </p>
    </div>
  );
}
