# AegisIQ — 90-day Go-to-Market plan

**Goal:** From 0 paying users to first $1,000 in MRR in 90 days, with under $500 in cash spend.

## Week 1-2 — Foundation

- [ ] Register `aegisiq.io` (Cloudflare Registrar, ~$12/year) and point it at Render.
- [ ] Point `www.aegisiq.io` and `app.aegisiq.io` at frontend; `api.aegisiq.io` at backend.
- [ ] Create `sales@aegisiq.io` alias (Cloudflare Email Routing → your inbox).
- [ ] Publish `aegisiq.io/deck` (the pitch deck HTML) and `aegisiq.io/pricing` (the pricing landing page).
- [ ] Add Plausible or Umami analytics (privacy-friendly, no cookie banner needed).
- [ ] Set up Stripe account, create Pro subscription price (`price_XXXX`), add ID to Render env as `VITE_STRIPE_PRO_PRICE_ID`.

## Week 3-4 — Launch

- [ ] **Show HN post** ("Show HN: AegisIQ — the Arabic-native SIEM Splunk pretends doesn't exist"). Post Tuesday 8am PT.
- [ ] **Product Hunt launch.** Schedule for a Wednesday. Line up 20 friends to upvote in the first hour.
- [ ] **Reddit posts** — r/cybersecurity, r/sysadmin, r/selfhosted, r/opensource. One post per subreddit, one week apart.
- [ ] **Dev.to / Hashnode article** — "How I built a $49/month SIEM in FastAPI + React." Include the pitch deck link.
- [ ] **YouTube demo (5 min)** — walkthrough of dashboard → alert → Copilot → SOAR → compliance report. Bilingual audio track.

**Target metric:** 300 GitHub stars, 15 email leads.

## Week 5-8 — Design partners

- [ ] Cold-email 30 CISOs / SecOps managers in GCC + Levant. Personalize by industry.
- [ ] Offer 3 design-partner slots: 6 months free Pro in exchange for a testimonial and a monthly 30-min call.
- [ ] Book 5 discovery calls. Ship whatever specific feature the first design partner asks for (within reason).
- [ ] Publish first design partner logo on landing page (with permission).
- [ ] Second Show HN post: "Show HN: AegisIQ now with multi-tenant" (once shipped).

**Target metric:** 3 design partners, first paying invoice sent (even $99).

## Week 9-12 — First revenue

- [ ] Convert first design partner from free to paid ($49 × seats).
- [ ] Sponsor one regional podcast or Discord community ($100-300).
- [ ] Attend GISEC or JSAC as an attendee (not exhibitor) — talk to 20 people, hand out one-pagers.
- [ ] Publish case study from design partner #1.
- [ ] Reach out to 5 MSSPs about reseller program.

**Target metric:** $1,000 MRR, 5 paying customers, 1 MSSP interested.

## Content calendar

Two pieces per week, alternating:

- **Monday:** Arabic-language technical post (LinkedIn + Substack). Topics: كيف تُنشئ SOC بـ50$ شهرياً، ماذا يعني SOC 2 لشركة صغيرة، إلخ.
- **Thursday:** English technical post (dev.to + Hacker News as comment/reply bait). Topics: detection rule internals, HMAC-signed containment, fail-open architecture.

## Channels ranked by expected ROI

1. **Show HN + Product Hunt** — free, huge one-time spikes.
2. **Cold outreach to MENA CISOs** — high touch, high close rate for design partners.
3. **YouTube demos** — long tail, compounds forever.
4. **Reddit posts** — pattern-match traffic, no direct conversion.
5. **Twitter/X** — noise, unless you already have followers.
6. **Paid ads** — DO NOT until you have a repeatable close.

## What NOT to do in the first 90 days

- ❌ Redesign the logo three times.
- ❌ Add a fourth feature before shipping multi-tenant.
- ❌ Chase enterprise deals before you have Pro conversion data.
- ❌ Raise a funding round before you have a paying customer.
- ❌ Hire before you have $5k MRR.
- ❌ Argue on Twitter about your comparison table.
