# AegisIQ v2.6 — Security audit notes

Self-audit performed alongside the v2.6 billing + scheduler additions. Findings and mitigations are recorded here so a future maintainer (or an acquirer's due-diligence team) has a paper trail.

## In scope

- `backend/app/billing/stripe_client.py`
- `backend/app/billing/routes.py`
- `backend/app/scheduled/compliance_scheduler.py`
- `frontend/src/pages/Pricing.tsx`

## Findings

### F-1: Stripe API key handling — PASS
- Key read only from `STRIPE_SECRET_KEY` env var; never logged, never returned in any response body.
- No third-party Stripe SDK — direct urllib.request calls to `https://api.stripe.com/v1`. Zero supply-chain dependencies for the billing surface.
- `is_configured()` returns bool without leaking the key length or prefix.
- `billing_status` returns only `mode` ("live"/"test"/"not_configured"), never the key material.

### F-2: Webhook signature verification — PASS
- Constant-time comparison via `hmac.compare_digest` — no timing oracle.
- Replay window enforced at 300 s (matches Stripe's SDK default).
- Only v1 (SHA256) signatures accepted; malformed headers reject cleanly with generic 400.
- Never trusts the event body before signature passes.
- Fails closed when secret is configured and signature is bad. Fails open (documents "no_secret_configured") only when secret is absent — appropriate for dev.

### F-3: Checkout redirect open-redirect risk — MITIGATED
- `success_url` and `cancel_url` derived server-side from `request.url` — cannot be steered by the client.
- User-supplied `customer_email` validated by Pydantic `EmailStr` before hitting Stripe.

### F-4: Scheduler resource exhaustion — PASS
- Runs exactly one tick every 3600 s (`CHECK_INTERVAL_SECONDS`).
- Uses `asyncio.Event` for stop — cannot leak on hot-reload.
- Delivery webhook has 8-second timeout; a hanging endpoint cannot stall the loop.
- `_generate_and_deliver_once` swallows exceptions per-report so one broken framework does not kill the run.

### F-5: Pricing page XSS surface — PASS
- All rendered content comes from `/api/billing/status` (server-controlled) and Pydantic-validated inputs.
- No `dangerouslySetInnerHTML`, no `eval`, no `new Function` anywhere in the drop.
- Stripe redirect URL used with `window.location.href` — safe target, no HTML injection.
- Fallback `mailto:` URL is pre-encoded and static; user input never composes it.

### F-6: License key exposure risk — PASS
- The existing v2.1 `PREMIUM_LICENSE_KEY` config is unchanged.
- New billing tier does NOT use the license-key mechanism (Stripe subscription is the source of truth in Pro/Enterprise).
- No secrets added to any frontend code — `VITE_STRIPE_PRO_PRICE_ID` is a Price ID (public by Stripe design), not a secret key.

## Recommended follow-ups (out of scope for v2.6)

1. Add per-org subscription state persistence in `subscriptions` table (currently the webhook just verifies but doesn't persist state).
2. Add rate limit on `/api/billing/checkout` (auth already covers it, but a compromised user token could spam Stripe API calls).
3. Add Stripe idempotency keys to the checkout POST so a double-click doesn't create two sessions.
4. Wire `subscription.updated`, `invoice.payment_failed`, `customer.subscription.deleted` webhook handlers to gate Pro features.
5. Add CSP header `Content-Security-Policy: default-src 'self'; connect-src 'self' https://api.stripe.com;` to the frontend for defense-in-depth.

None of the above blocks a v2.6 release. All are low-severity hardening for the eventual production billing plumbing.

## Signed
Self-audit performed by the author (`clouduni99@gmail.com`) on **September 13, 2026**, alongside the v2.6 commit.
