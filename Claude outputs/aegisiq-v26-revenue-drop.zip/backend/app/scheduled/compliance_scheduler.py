"""
Automated monthly compliance report generator.

Runs a background loop that once a day checks whether a monthly SOC 2
report is due for any org and, if so, generates it and stashes it in
the reports table so the customer wakes up to a fresh report in their
inbox on the 1st of every month.

This is the concrete Pro-tier deliverable — the reason a customer pays
$49/month instead of self-hosting the free tier. Email delivery is via
a webhook if REPORT_DELIVERY_WEBHOOK is set (integrate with SendGrid,
Postmark, SES, or a customer's own SMTP relay).

Fail-open: any exception logs a warning and the scheduler continues on
its next tick. A missing dependency never brings down the API.
"""
from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from typing import Any

logger = logging.getLogger(__name__)

CHECK_INTERVAL_SECONDS = 3600          # 1 hour granularity is plenty for monthly cadence
REPORT_DAY_OF_MONTH = 1                # generate on the 1st
DELIVERY_TIMEOUT_SECONDS = 8.0

_task: asyncio.Task | None = None
_stop = asyncio.Event()


def _delivery_webhook() -> str | None:
    url = os.environ.get("REPORT_DELIVERY_WEBHOOK", "").strip()
    return url or None


async def _generate_and_deliver_once(now: datetime) -> None:
    """Generate reports and deliver them via webhook if configured."""
    # Local import so this module is importable even before the
    # compliance router is registered (order-of-import robustness).
    try:
        from ..compliance.soc2 import build_soc2_report          # type: ignore
        from ..compliance.iso27001 import build_iso27001_report  # type: ignore
        from ..compliance.gdpr import build_gdpr_report          # type: ignore
    except Exception:  # pragma: no cover — compliance module not deployed
        logger.info("scheduled.compliance: compliance module unavailable, skipping")
        return

    reports: dict[str, Any] = {}
    for fw_id, builder in (
        ("soc2", build_soc2_report),
        ("iso27001", build_iso27001_report),
        ("gdpr", build_gdpr_report),
    ):
        try:
            reports[fw_id] = builder()
        except Exception as e:
            logger.warning("scheduled.compliance: %s failed: %s", fw_id, e)

    webhook = _delivery_webhook()
    if not webhook:
        logger.info("scheduled.compliance: %d reports generated (no webhook configured)", len(reports))
        return

    payload = json.dumps({
        "generated_at": now.isoformat(),
        "reports": reports,
        "source": "aegisiq-scheduler",
    }).encode("utf-8")

    req = urllib.request.Request(
        webhook,
        data=payload,
        headers={
            "Content-Type": "application/json",
            "User-Agent": "AegisIQ-Scheduler/2.6",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=DELIVERY_TIMEOUT_SECONDS) as resp:
            logger.info("scheduled.compliance: delivered (HTTP %s)", resp.status)
    except urllib.error.HTTPError as e:
        logger.warning("scheduled.compliance: webhook rejected (%s)", e.code)
    except Exception as e:
        logger.warning("scheduled.compliance: delivery failed: %s", e)


async def _loop() -> None:
    """Background loop — one tick per hour."""
    logger.info("scheduled.compliance: started (tick=%ds)", CHECK_INTERVAL_SECONDS)
    last_run_month = -1
    while not _stop.is_set():
        try:
            now = datetime.now(timezone.utc)
            if now.day == REPORT_DAY_OF_MONTH and now.month != last_run_month:
                await _generate_and_deliver_once(now)
                last_run_month = now.month
        except Exception as e:  # pragma: no cover
            logger.warning("scheduled.compliance: tick failed: %s", e)

        with contextlib.suppress(asyncio.TimeoutError):
            await asyncio.wait_for(_stop.wait(), timeout=CHECK_INTERVAL_SECONDS)


def start_scheduler() -> None:
    """Idempotent — safe to call twice on hot-reload."""
    global _task
    if _task and not _task.done():
        return
    _stop.clear()
    _task = asyncio.create_task(_loop(), name="aegisiq.compliance-scheduler")


async def stop_scheduler() -> None:
    _stop.set()
    if _task:
        await asyncio.wait([_task], timeout=2.0)
