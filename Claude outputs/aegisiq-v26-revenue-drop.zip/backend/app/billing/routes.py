"""
/api/billing/* — checkout, portal, and Stripe webhook verification.

Webhook signature verification is done in constant time against
STRIPE_WEBHOOK_SECRET; failed signatures return 400 without leaking
which part failed, and no event body is trusted before the signature
passes. This matches Stripe's recommended verification recipe.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import time

from fastapi import APIRouter, Depends, Header, HTTPException, Request, status
from pydantic import BaseModel, EmailStr, Field

from ..auth.dependencies import get_current_user
from ..models.user import User
from . import stripe_client

router = APIRouter(prefix="/api/billing", tags=["billing"])

# 5 minutes matches Stripe's SDK default and is well within the
# 5-minute replay window Stripe protects for you.
WEBHOOK_TOLERANCE_SECONDS = 300


class CheckoutRequest(BaseModel):
    price_id: str = Field(min_length=4, max_length=64)
    quantity: int = Field(default=1, ge=1, le=100)
    customer_email: EmailStr | None = None


class CheckoutResponse(BaseModel):
    session_id: str
    checkout_url: str
    mode: str  # "live" | "test" | "not_configured"
    fallback_mailto: str | None = None


class BillingStatus(BaseModel):
    configured: bool
    mode: str  # "live" | "test" | "not_configured"
    plans: list[dict]


@router.get("/status", response_model=BillingStatus)
def billing_status() -> BillingStatus:
    key = os.environ.get("STRIPE_SECRET_KEY", "").strip()
    if not key:
        mode = "not_configured"
    else:
        mode = "test" if key.startswith("sk_test_") else "live"
    return BillingStatus(
        configured=bool(key),
        mode=mode,
        plans=[
            {"id": "community", "name": "Community", "price_usd": 0, "features": ["Self-hosted", "Unlimited events", "All detection rules"]},
            {"id": "pro",       "name": "Pro",       "price_usd": 49, "features": ["Everything in Community", "AI Copilot", "Threat Intel enrichment", "Compliance reports (SOC 2 / ISO / GDPR)", "Email support"]},
            {"id": "enterprise","name": "Enterprise","price_usd": 0,  "features": ["Everything in Pro", "Multi-tenant workspaces", "SSO / SAML", "Priority support + SLA", "Custom detection rules"], "contact_sales": True},
        ],
    )


@router.post("/checkout", response_model=CheckoutResponse)
def create_checkout(
    body: CheckoutRequest,
    request: Request,
    current_user: User = Depends(get_current_user),
) -> CheckoutResponse:
    origin = f"{request.url.scheme}://{request.url.hostname}"
    if request.url.port and request.url.port not in (80, 443):
        origin += f":{request.url.port}"

    session = stripe_client.create_checkout_session(
        price_id=body.price_id,
        success_url=f"{origin}/billing/success?session_id={{CHECKOUT_SESSION_ID}}",
        cancel_url=f"{origin}/pricing?canceled=1",
        customer_email=body.customer_email or current_user.email,
        quantity=body.quantity,
    )
    fallback = None
    if session.mode == "not_configured":
        fallback = "mailto:sales@aegisiq.io?subject=AegisIQ%20Pro%20trial"
    return CheckoutResponse(
        session_id=session.id,
        checkout_url=session.url,
        mode=session.mode,
        fallback_mailto=fallback,
    )


@router.post("/webhook", status_code=status.HTTP_200_OK)
async def stripe_webhook(
    request: Request,
    stripe_signature: str = Header(default="", alias="Stripe-Signature"),
) -> dict:
    """Verify signature, then log the event. Actual subscription state
    changes are handled by the billing service (out of scope for v2.6
    — we ship the safe verifier now so real webhooks can plug in later).
    """
    secret = os.environ.get("STRIPE_WEBHOOK_SECRET", "").strip()
    if not secret:
        # Silently accept in dev mode with a distinct code, so a
        # mis-configured production instance still gets a 400 below.
        return {"received": True, "verified": False, "reason": "no_secret_configured"}

    raw = await request.body()
    if not _verify_stripe_signature(raw, stripe_signature, secret):
        raise HTTPException(status_code=400, detail="invalid_signature")
    # Signature verified. In future: dispatch event["type"] to handlers.
    return {"received": True, "verified": True}


def _verify_stripe_signature(payload: bytes, header: str, secret: str) -> bool:
    """Constant-time signature verification.

    Stripe-Signature header format: "t=1234567890,v1=hex_sha256,v0=..."
    We accept only v1 (SHA256 HMAC) and enforce a replay window.
    """
    if not header:
        return False
    parts: dict[str, str] = {}
    for chunk in header.split(","):
        if "=" not in chunk:
            continue
        k, _, v = chunk.partition("=")
        parts.setdefault(k.strip(), v.strip())
    ts = parts.get("t")
    sig = parts.get("v1")
    if not ts or not sig:
        return False
    try:
        ts_int = int(ts)
    except ValueError:
        return False
    if abs(int(time.time()) - ts_int) > WEBHOOK_TOLERANCE_SECONDS:
        return False
    signed = f"{ts}.".encode("utf-8") + payload
    expected = hmac.new(secret.encode("utf-8"), signed, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, sig)
