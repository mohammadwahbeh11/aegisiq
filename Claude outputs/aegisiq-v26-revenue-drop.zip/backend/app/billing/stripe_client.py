"""
Stripe integration for AegisIQ Pro subscriptions.

Uses stdlib urllib.request only — no third-party SDK — so the module
imports cleanly on any Python 3.11+ environment without extra deps and
without adding a supply-chain attack surface for a security product.

Fail-open: if STRIPE_SECRET_KEY is not set, every method returns a
"stripe_not_configured" marker instead of raising. The rest of the app
keeps working; the pricing page just tells the user to contact sales.
"""
from __future__ import annotations

import json
import os
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any

STRIPE_API = "https://api.stripe.com/v1"
STRIPE_TIMEOUT_SECONDS = 6.0


@dataclass(frozen=True)
class CheckoutSession:
    id: str
    url: str
    mode: str  # "live" or "test" or "not_configured"


class StripeError(RuntimeError):
    """Raised only on operator-facing errors (bad key, malformed request).

    Missing-configuration NEVER raises — callers get the sentinel from
    create_checkout_session instead so the UI stays responsive.
    """


def _api_key() -> str | None:
    key = os.environ.get("STRIPE_SECRET_KEY", "").strip()
    return key or None


def is_configured() -> bool:
    return _api_key() is not None


def _post(path: str, form: dict[str, str]) -> dict[str, Any]:
    key = _api_key()
    if key is None:
        raise StripeError("stripe_not_configured")
    data = urllib.parse.urlencode(form).encode("utf-8")
    req = urllib.request.Request(
        f"{STRIPE_API}{path}",
        data=data,
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": "AegisIQ/2.6 (+https://aegisiq.io)",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=STRIPE_TIMEOUT_SECONDS) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise StripeError(f"stripe_http_{e.code}: {body[:200]}") from None
    except Exception as e:  # pragma: no cover
        raise StripeError(f"stripe_transport: {e}") from None
    try:
        return json.loads(body)
    except json.JSONDecodeError:
        raise StripeError("stripe_bad_json") from None


def create_checkout_session(
    *,
    price_id: str,
    success_url: str,
    cancel_url: str,
    customer_email: str | None = None,
    quantity: int = 1,
) -> CheckoutSession:
    """Create a Stripe Checkout session for a Pro subscription.

    Returns a sentinel CheckoutSession with mode="not_configured" if
    Stripe is not set up — the frontend then falls back to a
    mailto: sales link so the pricing page still converts leads.
    """
    if not is_configured():
        return CheckoutSession(id="", url="", mode="not_configured")

    form = {
        "mode": "subscription",
        "line_items[0][price]": price_id,
        "line_items[0][quantity]": str(quantity),
        "success_url": success_url,
        "cancel_url": cancel_url,
        "allow_promotion_codes": "true",
        "billing_address_collection": "auto",
        "automatic_tax[enabled]": "true",
    }
    if customer_email:
        form["customer_email"] = customer_email

    payload = _post("/checkout/sessions", form)
    key = _api_key() or ""
    mode = "test" if key.startswith("sk_test_") else "live"
    return CheckoutSession(id=payload["id"], url=payload["url"], mode=mode)


def create_billing_portal_session(*, customer_id: str, return_url: str) -> str:
    """URL to Stripe's hosted billing portal (invoice history, cancel, update card)."""
    if not is_configured():
        return ""
    payload = _post(
        "/billing_portal/sessions",
        {"customer": customer_id, "return_url": return_url},
    )
    return payload.get("url", "")
