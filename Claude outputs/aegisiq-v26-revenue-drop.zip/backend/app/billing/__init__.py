"""Billing & subscription management for AegisIQ commercial tier."""
