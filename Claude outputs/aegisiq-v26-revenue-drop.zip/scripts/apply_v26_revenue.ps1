# apply_v26_revenue.ps1 -- install AegisIQ v2.6 revenue features into the local repo.
# Run from the drop folder (or with absolute paths). Idempotent.

$ErrorActionPreference = 'Stop'
$repo = "C:\Users\ONE BY ONE\Downloads\lightweight-siem"
$src  = $PSScriptRoot     # this script's folder = drop\scripts
$drop = Split-Path $src -Parent

Write-Host "Applying v2.6 to: $repo"

function CopyFile($rel) {
    $from = Join-Path $drop $rel
    $to   = Join-Path $repo $rel
    $dir  = Split-Path $to -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    Copy-Item -Force $from $to
    Write-Host "  OK $rel"
}

# Backend
CopyFile 'backend\app\billing\__init__.py'
CopyFile 'backend\app\billing\stripe_client.py'
CopyFile 'backend\app\billing\routes.py'
CopyFile 'backend\app\scheduled\__init__.py'
CopyFile 'backend\app\scheduled\compliance_scheduler.py'

# Frontend
CopyFile 'frontend\src\pages\Pricing.tsx'

# Marketing / docs
CopyFile 'marketing\pitch_deck.html'
CopyFile 'marketing\pricing_landing.html'
CopyFile 'docs\VALUATION.md'
CopyFile 'docs\GO_TO_MARKET.md'
CopyFile 'docs\SECURITY_AUDIT_v26.md'
CopyFile 'LICENSE_COMMERCIAL.md'

# ---- Patch backend main.py ----
$mainPath = Join-Path $repo 'backend\app\main.py'
if (Test-Path $mainPath) {
    $main = Get-Content $mainPath -Raw
    $changed = $false
    if ($main -notmatch 'from \.billing import routes as billing_routes') {
        $main = $main -replace '(from fastapi import FastAPI)', "`$1`r`nfrom .billing import routes as billing_routes"
        $changed = $true
    }
    if ($main -notmatch 'app\.include_router\(billing_routes\.router\)') {
        # append after last include_router (best-effort)
        $main = $main -replace '(app\.include_router\([^)]+\))(\s*\r?\n)(?!.*app\.include_router)', "`$1`r`napp.include_router(billing_routes.router)`$2"
        $changed = $true
    }
    if ($main -notmatch 'from \.scheduled\.compliance_scheduler') {
        $main += "`r`n`r`n# v2.6 scheduled tasks`r`nfrom .scheduled.compliance_scheduler import start_scheduler, stop_scheduler`r`n@app.on_event('startup')`r`nasync def _v26_start(): start_scheduler()`r`n@app.on_event('shutdown')`r`nasync def _v26_stop(): await stop_scheduler()`r`n"
        $changed = $true
    }
    if ($changed) {
        Set-Content -Path $mainPath -Value $main -NoNewline
        Write-Host "  OK backend/app/main.py patched"
    } else {
        Write-Host "  SKIP backend/app/main.py already patched"
    }
}

# ---- Patch frontend App.tsx ----
$appPath = Join-Path $repo 'frontend\src\App.tsx'
$app = Get-Content $appPath -Raw
if ($app -notmatch 'import Pricing') {
    $app = $app -replace '(import Intelligence from "\./pages/Intelligence";)', "`$1`r`nimport Pricing from `"./pages/Pricing`";"
    $app = $app -replace '(<Route path="/intelligence" element=\{<Intelligence />\} />)', "`$1`r`n        <Route path=`"/pricing`" element={<Pricing />} />"
    Set-Content -Path $appPath -Value $app -NoNewline
    Write-Host "  OK frontend/src/App.tsx routed /pricing"
} else {
    Write-Host "  SKIP App.tsx already routed"
}

# ---- Patch Layout.tsx nav ----
$layoutPath = Join-Path $repo 'frontend\src\components\Layout.tsx'
$layout = Get-Content $layoutPath -Raw
if ($layout -notmatch '/pricing') {
    $layout = $layout -replace '(\{ to: "/intelligence",\s*label: "Intelligence",\s*glyph: "[^"]+", pro: true \},)', "`$1`r`n      { to: `"/pricing`",     label: `"Pricing`",          glyph: `"$`", pro: true },"
    Set-Content -Path $layoutPath -Value $layout -NoNewline
    Write-Host "  OK Layout.tsx nav updated"
} else {
    Write-Host "  SKIP Layout.tsx already has /pricing"
}

Write-Host ""
Write-Host "v2.6 patch complete. Next:"
Write-Host "  cd `"$repo\frontend`"; npm run build; cd .."
Write-Host "  git add ."
Write-Host "  git commit -m `"feat: v2.6 revenue - billing + scheduler + pitch deck + valuation`""
Write-Host "  git push"
