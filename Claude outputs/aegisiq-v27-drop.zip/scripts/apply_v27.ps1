# apply_v27.ps1 -- install AegisIQ v2.7 (Kill-Switch v2, rule library, frontend polish).

$ErrorActionPreference = 'Stop'
$repo = "C:\Users\ONE BY ONE\Downloads\lightweight-siem"
$src  = $PSScriptRoot
$drop = Split-Path $src -Parent

Write-Host "Applying v2.7 to: $repo"

function CopyFile($rel) {
    $from = Join-Path $drop $rel
    $to   = Join-Path $repo $rel
    $dir  = Split-Path $to -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    Copy-Item -Force $from $to
    Write-Host "  OK $rel"
}

# 1) Kill-Switch v2 agent -- replaces the v2.5 agent
CopyFile 'agent\kill_switch_agent_v2.py'

# 2) Rule library backend
CopyFile 'backend\app\detection\rule_pack_loader.py'
CopyFile 'backend\app\detection\rules_api.py'

# 3) 10 curated AegisIQ rules
$rulesDir = Join-Path $repo 'sigma_rules\aegisiq'
if (-not (Test-Path $rulesDir)) { New-Item -ItemType Directory -Force -Path $rulesDir | Out-Null }
Get-ChildItem (Join-Path $drop 'sigma_rules\aegisiq') -Filter '*.yml' | ForEach-Object {
    Copy-Item -Force $_.FullName (Join-Path $rulesDir $_.Name)
    Write-Host "  OK sigma_rules\aegisiq\$($_.Name)"
}

# 4) Frontend RulesLibrary page + CSS polish
CopyFile 'frontend\src\pages\RulesLibrary.tsx'

# Append the CSS polish to index.css (idempotent guard)
$cssPath = Join-Path $repo 'frontend\src\index.css'
$polishPath = Join-Path $drop 'frontend\src\pages\frontend_polish.css'
$css = Get-Content $cssPath -Raw
if ($css -notmatch 'v2\.7 frontend polish') {
    Add-Content -Path $cssPath -Value "`r`n`r`n$(Get-Content $polishPath -Raw)"
    Write-Host "  OK index.css polished"
} else {
    Write-Host "  SKIP index.css already polished"
}

# 5) Patch backend main.py -- register the rules router
$mainPath = Join-Path $repo 'backend\app\main.py'
if (Test-Path $mainPath) {
    $main = Get-Content $mainPath -Raw
    if ($main -notmatch 'from \.detection import rules_api') {
        $main = $main -replace '(from fastapi import FastAPI)', "`$1`r`nfrom .detection import rules_api"
        $main = $main -replace '(app\.include_router\([^)]+\))(\s*\r?\n)(?!.*app\.include_router\(rules_api)', "`$1`r`napp.include_router(rules_api.router)`$2"
        Set-Content -Path $mainPath -Value $main -NoNewline
        Write-Host "  OK backend/app/main.py routes rules_api"
    } else {
        Write-Host "  SKIP main.py already routes rules_api"
    }
}

# 6) Patch frontend App.tsx and Layout.tsx
$appPath = Join-Path $repo 'frontend\src\App.tsx'
$app = Get-Content $appPath -Raw
if ($app -notmatch 'import RulesLibrary') {
    $app = $app -replace '(import Intelligence from "\./pages/Intelligence";)', "`$1`r`nimport RulesLibrary from `"./pages/RulesLibrary`";"
    $app = $app -replace '(<Route path="/intelligence" element=\{<Intelligence />\} />)', "`$1`r`n        <Route path=`"/rules-library`" element={<RulesLibrary />} />"
    Set-Content -Path $appPath -Value $app -NoNewline
    Write-Host "  OK frontend/src/App.tsx routes /rules-library"
} else {
    Write-Host "  SKIP App.tsx already routes /rules-library"
}

$layoutPath = Join-Path $repo 'frontend\src\components\Layout.tsx'
$layout = Get-Content $layoutPath -Raw
if ($layout -notmatch '/rules-library') {
    $layout = $layout -replace '(\{ to: "/intelligence",\s*label: "Intelligence",\s*glyph: "[^"]+", pro: true \},)', "`$1`r`n      { to: `"/rules-library`", label: `"Rules library`",     glyph: `"#`", pro: true },"
    Set-Content -Path $layoutPath -Value $layout -NoNewline
    Write-Host "  OK Layout.tsx nav has Rules library"
} else {
    Write-Host "  SKIP Layout.tsx already has rules-library"
}

Write-Host ""
Write-Host "v2.7 patch complete."
Write-Host ""
Write-Host "Backend deps: PyYAML is required for community rule sync. Add to requirements.txt if missing:"
Write-Host "  pyyaml>=6.0"
Write-Host ""
Write-Host "Then:"
Write-Host "  cd $repo\frontend; npm run build; cd .."
Write-Host "  git add ."
Write-Host "  git commit -m `"feat: v2.7 - Kill-Switch v2, rule library (1000+ via SigmaHQ), frontend polish`""
Write-Host "  git push"
