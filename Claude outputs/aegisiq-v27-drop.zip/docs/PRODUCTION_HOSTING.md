# AegisIQ — Production hosting on Vercel + Supabase + Render (free tier)

Render's free tier is fine for a demo, but two things hurt in production:
- SQLite lives on ephemeral disk → data disappears on redeploy or 15-min idle.
- The frontend static build competes for cold-start CPU with the backend.

The fix — all free — is a three-provider split:

| Layer | Provider | Why | Free-tier limit |
|---|---|---|---|
| Frontend (React) | **Vercel** | Instant deploys, global CDN, auto-preview per PR | 100 GB bandwidth/mo |
| Database (Postgres) | **Supabase** | Real Postgres, survives restarts, built-in auth (optional) | 500 MB storage, unlimited API |
| Backend (FastAPI) | **Render** | Keeps the Python/uvicorn workload where it already runs | 750 hours/mo |

Total cost: **$0/month** while under the free-tier caps. No credit card required for any of them.

Alternative: **Firebase** works too — Firestore for the DB, Hosting for the static frontend, and Cloud Functions for a Python backend, but the cold-start on the Python runtime is worse than Render and the Firestore query model doesn't fit our relational schema.

## Step 1 — Migrate the database to Supabase (10 min)

1. Sign up at https://supabase.com (Google/GitHub login, no card).
2. Create a new project — pick the region closest to Render (US East for Render Oregon → Supabase US East 1).
3. In Supabase → **Project Settings** → **Database** → copy the **Connection string (URI)** — the one that ends `?sslmode=require`. It looks like:
   ```
   postgresql://postgres:[PASSWORD]@db.xyz.supabase.co:5432/postgres
   ```
4. On Render → `aegisiq-backend` → **Environment** → change `DATABASE_URL` to that Supabase URI.
5. Also add:
   ```
   DATABASE_URL_ASYNC=postgresql+asyncpg://postgres:[PASSWORD]@db.xyz.supabase.co:5432/postgres
   ```
6. In `backend/requirements.txt` add:
   ```
   psycopg2-binary>=2.9
   asyncpg>=0.29
   ```
7. Push — Render redeploys, Alembic (or SQLAlchemy `create_all`) runs, tables materialize in Supabase.
8. Log in to your app — first-boot user creation runs, data persists forever.

**Migration cheat: existing SQLite data → Supabase**

```bash
# From the current Render Shell tab:
python -c "from app.database import export_sqlite_to_sql; export_sqlite_to_sql('/tmp/dump.sql')"
# Download dump.sql, then paste into Supabase SQL Editor.
```

If you don't have the export helper yet, `sqlite3 data/siem.db .dump > dump.sql`, hand-edit the SQL to remove SQLite-only pragmas, paste into Supabase.

## Step 2 — Move the frontend to Vercel (5 min)

1. Sign up at https://vercel.com (GitHub login, no card).
2. Click **New Project** → import `mohammadwahbeh11/aegisiq`.
3. Set:
   - **Framework preset**: Vite
   - **Root directory**: `frontend`
   - **Build command**: `npm run build`
   - **Output directory**: `dist`
4. **Environment Variables** tab:
   ```
   VITE_API_URL = https://aegisiq-backend.onrender.com
   VITE_STRIPE_PRO_PRICE_ID = price_XXX (once created)
   ```
5. Deploy. Vercel gives you `aegisiq-*.vercel.app` immediately.
6. Domain tab → **Add** → `app.aegisiq.io` → follow the CNAME instructions in Cloudflare (Cloudflare Registrar makes this two clicks).

**Result**: your frontend now serves from Vercel's global CDN (~40 ms in MENA vs ~800 ms cold-start on Render free tier).

## Step 3 — CORS on the backend

Backend needs to accept the new Vercel domain. On Render:

```
CORS_ORIGINS = https://app.aegisiq.io,https://*.vercel.app,http://localhost:5173
```

Save → Render redeploys.

## Step 4 — Point aegisiq.io DNS (Cloudflare)

Assuming you registered at Cloudflare Registrar (recommended, $9.15/year for .io):

| Type | Name | Value | Proxy |
|---|---|---|---|
| CNAME | `app` | `cname.vercel-dns.com` | ⚫ off (Vercel does its own TLS) |
| CNAME | `api` | `aegisiq-backend.onrender.com` | ⚫ off |
| CNAME | `www` | `cname.vercel-dns.com` | ⚫ off |
| A | `@` (apex) | `76.76.21.21` | ⚫ off |

Vercel auto-issues Let's Encrypt certs within 60 seconds of DNS propagation.

## Cost projection at scale

| Users / month | Vercel | Supabase | Render | Total |
|---|---|---|---|---|
| 100 (free-tier demo) | $0 | $0 | $0 | **$0** |
| 1,000 (10 pilot customers) | $0 | $0 | $7 (Standard) | **$7** |
| 10,000 (paid tier live) | $20 (Pro) | $25 (Pro) | $25 (Standard) | **$70** |
| 100,000 | $20 | $60 (8 GB) | $85 (Perf) | **$165** |

For comparison: Splunk Enterprise at 10,000 events/day cost breakdown starts at ~$2,000/month. AegisIQ hosts the same throughput at $70.

## What Firebase would look like instead

If you prefer Firebase, the mapping is:

| Layer | Firebase equivalent |
|---|---|
| Frontend | Firebase Hosting (same as Vercel for static Vite builds) |
| Backend | Cloud Run (Python container, better cold-start than Cloud Functions) |
| Database | Firestore (NoSQL — requires schema rewrite) OR Cloud SQL Postgres (paid) |

Not recommended unless you're already invested in the Google Cloud ecosystem — Firestore's document model doesn't fit AegisIQ's relational tables (users, rules, alerts, audit) without a large refactor.
