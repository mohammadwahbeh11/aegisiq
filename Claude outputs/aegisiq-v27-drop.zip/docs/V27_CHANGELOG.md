# AegisIQ v2.7 — Changelog

## Kill-Switch Agent v2

- **Cross-platform executors** — nftables/iptables (Linux), netsh (Windows), pf (macOS)
- **Signed action revocation** — unblock/enable operations follow the same HMAC path as block/disable
- **Tamper-evident local ledger** — SQLite with chained SHA-256 row hashes; `--verify-ledger` walks the chain
- **Auto-expiry fail-safe** — every block auto-lifts after `AEGIS_MAX_BLOCK_MINUTES` (default 60) so a bad rule cannot brick the host
- **Config from env OR /etc/aegisiq/agent.conf** — no hardcoded paths, no rebuild per deployment
- **TLS required by default** — `AEGIS_ALLOW_HTTP=1` explicit opt-out for lab-only use
- **Replay + clock-skew protection** — nonce set + 60s window
- **Zero third-party deps** — stdlib only, single file, drop-in
- **Dry-run mode** — `--dry-run` logs actions without executing (for testing)

## Detection Rules Library — 1000+ rules via SigmaHQ

Rather than hand-writing rules (that maintainers wouldn't keep current), v2.7:

1. Ships **10 hand-crafted AegisIQ core rules** for MENA-relevant scenarios:
   - SSH brute force with successful landing
   - RDP brute force from external IPs
   - Impossible travel (same user, two countries in 1h)
   - Large exfiltration to unseen destination
   - **MENA-region phishing with Arabic financial keywords** (unique)
   - PowerShell encoded command execution
   - AWS root account usage
   - Kubernetes privileged container creation
   - Ransomware shadow-copy deletion
   - Web shell indicator (shell spawned by web server)

2. Adds **`/api/rules/sync`** — one click pulls ~3000 community rules from SigmaHQ (MIT-licensed), parses them with PyYAML, de-duplicates by Sigma UUID, and stores with `source='sigma_community'`.

3. Marks rules as `ingestable: true/false` based on whether AegisIQ's ingest pipeline currently receives that logsource — so the UI can hide rules that need a data source you don't have yet.

## Backend cleanup

- New `detection/rule_pack_loader.py` — one loader for local + community rules, deduped, testable in isolation
- New `detection/rules_api.py` — thin read/sync API, delegates loading, no detection logic
- Rules cache lives in module state — refreshed on startup + after each sync (no per-request tarball download)

## Frontend polish (index.css appended)

- Table rows hover-highlight for scannability
- Full mobile responsive collapse under 640px (nav, KPI grid, forms all stack)
- Focus-visible outlines for keyboard-only accessibility (WCAG 2.1 AA)
- Skeleton loading animation for Render cold-start UX
- RTL support blocks (Arabic Copilot responses render correctly)
- Print styles that hide chrome and keep only the body (compliance reports print to PDF cleanly)
- Reduced-motion honoring

## New page — Rules Library

`/rules-library` — customer-visible inventory of every detection rule loaded, with:

- Search box (title, sigma_id, tag)
- Level filter, source filter
- Live counters by source and level
- One-click sync from SigmaHQ (admin only)
- Non-ingestable rules clearly marked so customers know what needs a new data source

## Install

Fresh drop, apply like the previous ones:

```powershell
Expand-Archive -Force "C:\Users\ONE BY ONE\Downloads\aegisiq-v27-drop.zip" -DestinationPath "C:\Users\ONE BY ONE\Downloads\v27-drop"
powershell -ExecutionPolicy Bypass -File "C:\Users\ONE BY ONE\Downloads\v27-drop\scripts\apply_v27.ps1"

# Add PyYAML if not already in requirements.txt:
Add-Content "C:\Users\ONE BY ONE\Downloads\lightweight-siem\backend\requirements.txt" "`r`npyyaml>=6.0"

cd "C:\Users\ONE BY ONE\Downloads\lightweight-siem\frontend"; npm run build; cd ..
git add .
git commit -m "feat: v2.7 - Kill-Switch v2, 1000+ rules via SigmaHQ, frontend polish"
git push
```

## Post-deploy verification

1. Open `/rules-library` → confirms 10+ AegisIQ rules load with counters.
2. Click **Sync from SigmaHQ** (admin) → wait ~15s → counter jumps to ~2500+.
3. Search "ransomware" → returns hits.
4. Filter by critical → shows only critical rules.
5. On the agent host, run `sudo python3 kill_switch_agent_v2.py --verify-ledger` → prints `Ledger OK`.
