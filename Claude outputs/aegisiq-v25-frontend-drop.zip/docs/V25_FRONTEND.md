# AegisIQ v2.5 — Frontend Intelligence Page

This drop adds the missing UI for the three v2.5 backend modules so the paid
value story is visible the moment a customer logs in:

| Panel               | Backend endpoint(s)                                | What it shows                                  |
|---------------------|----------------------------------------------------|-----------------------------------------------|
| AI Copilot          | `GET /api/copilot/status`, `POST /api/copilot/explain/{id}` | Bilingual alert explanation (AR/EN), fail-open |
| IP Reputation       | `GET /api/enrichment/ip/{ip}`                      | Composite risk score, AbuseIPDB + OTX          |
| Compliance Evidence | `GET /api/compliance/frameworks`, `GET /api/compliance/{id}/report` | SOC 2 / ISO 27001 / GDPR reports |

## What's in this drop

```
frontend/src/pages/Intelligence.tsx      -- new page (~300 lines)
scripts/apply_v25_frontend.ps1           -- idempotent patcher for the Windows repo
scripts/demo_data_render.sh              -- populate the deployed instance
docs/V25_FRONTEND.md                     -- this file
```

## Install (on the Windows machine)

```powershell
cd "C:\Users\ONE BY ONE\Downloads\lightweight-siem"
# copy this whole drop folder into <repo>\_v25-drop\ then:
powershell -ExecutionPolicy Bypass -File _v25-drop\scripts\apply_v25_frontend.ps1
cd frontend
npm run build         # must succeed before pushing
cd ..
git add frontend/src scripts/demo_data_render.sh
git commit -m "feat(frontend): v2.5 Intelligence page — Copilot + Enrichment + Compliance"
git push
```

Render auto-deploys the frontend on push. Cold-start is ~30 s.

## Populate the empty dashboard

The freshly deployed dashboard shows zeros because SQLite in Render's free
tier is ephemeral. Run once to inject a realistic mix (brute force, port
scan, priv-esc, malware, exfil) — all from RFC 5737 test IPs so nothing
real is touched:

```bash
BASE_URL="https://aegisiq-backend.onrender.com" \
ADMIN_USER=admin ADMIN_PASS='YourAdminPassword' \
bash scripts/demo_data_render.sh
```

Refresh the dashboard — you should now see events across all severities and
SOAR containment actions on the critical alerts.

## Security spot-checks performed

The patcher (`apply_v25_frontend.ps1`) greps the frontend for
`dangerouslySetInnerHTML`, `eval(`, and `new Function(` — none are used by
the new page. The page renders every model-generated field with React's
default text escaping. The HTML report opens as a `Blob` in a new tab
(`noopener,noreferrer`), which cannot reach `window.opener`.

Client-side inputs are validated:
- Alert ID is parsed as an integer > 0.
- IP is checked against `/^[0-9a-fA-F:.]+$/` and length ≥ 3; the
  server does the authoritative validation and returns 400 on rejects.

The Copilot / Enrichment endpoints are token-authenticated (the shared
`apiClient` interceptor injects the JWT). Compliance report downloads are
admin-gated on the server; the button is also disabled client-side for
non-admin users.

## Fail-open behavior

If a Render deployment has no API keys configured:
- `/api/copilot/status` returns `configured: false` → the page still loads.
- `/api/enrichment/ip/*` returns HTTP 503 → the panel shows "not configured".
- `/api/compliance/frameworks` returning empty → the panel shows a friendly
  empty state instead of an error banner.

Nothing in the new UI can break a working dashboard.
