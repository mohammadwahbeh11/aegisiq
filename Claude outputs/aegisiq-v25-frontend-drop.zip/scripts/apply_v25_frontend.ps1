# ---------------------------------------------------------------------------
# apply_v25_frontend.ps1 — install the v2.5 Intelligence page into the local
# AegisIQ repo on this Windows machine, then commit + push.
#
# Run from PowerShell in the repo root:
#     powershell -ExecutionPolicy Bypass -File scripts\apply_v25_frontend.ps1
# ---------------------------------------------------------------------------
$ErrorActionPreference = 'Stop'

$repo = (Get-Location).Path
Write-Host "▶ Applying v2.5 frontend patch inside: $repo"

# 1) Copy the Intelligence page into place.
$pagesDir = Join-Path $repo 'frontend\src\pages'
if (-not (Test-Path $pagesDir)) { throw "Not in the repo root — $pagesDir missing." }

Copy-Item -Force `
    -Path (Join-Path $PSScriptRoot '..\frontend\src\pages\Intelligence.tsx') `
    -Destination (Join-Path $pagesDir 'Intelligence.tsx')
Write-Host "  ✓ Intelligence.tsx installed"

# 2) Patch App.tsx to add the route (idempotent).
$appPath = Join-Path $repo 'frontend\src\App.tsx'
$app = Get-Content $appPath -Raw
if ($app -notmatch 'import Intelligence') {
    $app = $app -replace `
        '(import Simulation from "\./pages/Simulation";)', `
        "`$1`r`nimport Intelligence from `"./pages/Intelligence`";  // v2.5"
    $app = $app -replace `
        '(<Route path="/simulation" element=\{<Simulation />\} />)', `
        "`$1`r`n        <Route path=`"/intelligence`" element={<Intelligence />} /> {/* v2.5 */}"
    Set-Content -Path $appPath -Value $app -NoNewline
    Write-Host "  ✓ App.tsx routed /intelligence"
} else {
    Write-Host "  = App.tsx already has the route"
}

# 3) Patch Layout.tsx nav — add Intelligence under the Premium section.
$layoutPath = Join-Path $repo 'frontend\src\components\Layout.tsx'
$layout = Get-Content $layoutPath -Raw
if ($layout -notmatch '/intelligence') {
    $layout = $layout -replace `
        '(\{ to: "/analysis",\s*label: "Log analysis",\s*glyph: "[^"]+", pro: true \},)', `
        "`$1`r`n      { to: `"/intelligence`", label: `"Intelligence`",     glyph: `"◊`", pro: true },"
    Set-Content -Path $layoutPath -Value $layout -NoNewline
    Write-Host "  ✓ Layout.tsx nav updated"
} else {
    Write-Host "  = Layout.tsx already has the nav entry"
}

# 4) Copy the demo-data script into repo scripts/.
$scriptsDir = Join-Path $repo 'scripts'
if (-not (Test-Path $scriptsDir)) { New-Item -ItemType Directory -Path $scriptsDir | Out-Null }
Copy-Item -Force `
    -Path (Join-Path $PSScriptRoot 'demo_data_render.sh') `
    -Destination (Join-Path $scriptsDir 'demo_data_render.sh')
Write-Host "  ✓ scripts\demo_data_render.sh installed"

# 5) Security audit note — quick local check for known bad patterns.
Write-Host "`n▶ Running quick security spot-checks…"
$hits = @()
Get-ChildItem -Recurse -Include *.tsx,*.ts -Path (Join-Path $repo 'frontend\src') |
    Select-String -Pattern 'dangerouslySetInnerHTML|eval\(|new Function\(' -List |
    ForEach-Object { $hits += $_.Path }
if ($hits.Count -eq 0) {
    Write-Host "  ✓ no XSS-adjacent sinks introduced by this patch"
} else {
    Write-Host "  ! Review these files for unsafe sinks:" -ForegroundColor Yellow
    $hits | ForEach-Object { Write-Host "    - $_" }
}

Write-Host "`n✓ Patch applied. Next:"
Write-Host "    cd frontend"
Write-Host "    npm install         # if you haven't yet"
Write-Host "    npm run build       # sanity check compile"
Write-Host "    cd .."
Write-Host "    git add frontend/src/pages/Intelligence.tsx frontend/src/App.tsx frontend/src/components/Layout.tsx scripts/demo_data_render.sh"
Write-Host "    git commit -m `"feat(frontend): v2.5 Intelligence page — Copilot + Enrichment + Compliance`""
Write-Host "    git push"
